/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersgames.com/
 * 
 * Settings
 * Stores assorted configurations for the engine Cores.
 */

package twelveengine;

public class Settings {
	/** Stores the OpenAL settings */
	public static Integer musicVolume = 100;
	public static Integer soundVolume = 100;
	/** Stores the Display settings */
	public static Integer displayWidth = 1280;
	public static Integer displayHeight = 720;
	public static Boolean enableFullscreen = false;
	public static Boolean enableVSync = true;
}
