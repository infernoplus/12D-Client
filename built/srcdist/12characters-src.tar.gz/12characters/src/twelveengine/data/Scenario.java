package twelveengine.data;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Scenario {
	public String file;
	
	public String name;
	public String bsp;
	
	public ArrayList<Vertex> spawns = new ArrayList<Vertex>();
	
	public Scenario(String s) {
		file = s;
		try {
			readScenario(s);
		} catch (IOException e) {
			System.err.println("FAILED TO READ SCENARIO: " + s);
		}
	}
	
	//TODO: Make this reader less DERP
	public void readScenario(String s) throws IOException {
		
		String currentLine;
		DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream("scenario/" + s));
	    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
	    
	    currentLine=fileReader.readLine();
	    while(!currentLine.equals("%EOF")) {
	    	if(currentLine.startsWith("level="))
	    		name = currentLine.split("=")[1];
	    	if(currentLine.startsWith("bsp="))
	    		bsp = currentLine.split("=")[1];
	    	if(currentLine.startsWith("vertex<")) {
	    		String t = currentLine.split("=")[1];
	    		String u = currentLine.split("=")[0].split("<", 2)[1].split(">")[0];
	    		spawns.add(new Vertex(Double.parseDouble(t.split(",",3)[0]), Double.parseDouble(t.split(",",3)[1]), Double.parseDouble(t.split(",",3)[2]), u));
	    	}
		    currentLine=fileReader.readLine();
	    }
	    fileReader.close();
	}
}
