package twelveengine.data;

import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.actors.Item;
import twelveengine.actors.Pawn;
import twelveengine.graphics.GraphicsCore;
import twelvelib.net.packets.Packet32Pickup;
import twelvelib.net.packets.Packet33Drop;
import twelveutil.MathUtil;

public class Player {
	public Game game;
	
	public ArrayList<Integer> keys = new ArrayList<Integer>();
	public int x = 0;
	public int y = 0;
	public int i = 0;
	public int j = 0;
	public boolean lmb;
	public boolean rmb;
	public boolean mmb;
	
	public Vertex cameraLocation = new Vertex(0, 0, 0);
	public Vertex cameraRotation = new Vertex(0, 0, 0);
	
	public Vertex look = new Vertex(0, 0, 0);
	
	public Pawn pawn;
	
	public Player(Game w) {
		game = w;
	}
	
	public void input() {
		mouse();
		keys();
		look();
		if(pawn != null) {
			interact();
		}
	}
	
	public void post() {
		camera();
		if(pawn != null)
			game.engine.ui.toggleInventory = true;
		else
			game.engine.ui.toggleInventory = false;
	}
	
	public void readKey(ArrayList<Integer> a) {
		keys = a;
	}
	
	public void readMouse(boolean l, boolean r, boolean m, int a, int b) {
		i += a;
		j += b;
		lmb = l;
		rmb = r;
		mmb = m;
	}
	
	public void mouse() {
		if(pawn != null) {
			pawn.primary = lmb;
			pawn.secondary = rmb;
		}
		

		cameraRotation.x+=i*0.2;
		cameraRotation.y+=j*-0.2;
		i = 0;
		j = 0;
	}
	
	public void look() {
		if(pawn != null) {
			double yrotrad = GraphicsCore.rot.z/180*3.141592654;
			double z = GraphicsCore.rot.x/180*3.141592654;
			double x = Math.abs(Math.sin((GraphicsCore.rot.x)/180*3.141592654))*Math.sin(yrotrad);
			double y = Math.abs(Math.sin((GraphicsCore.rot.x)/180*3.141592654))*Math.cos(yrotrad);
			pawn.look = MathUtil.normalize(new Vertex(x,y,-Math.cos(z)));
			pawn.move = MathUtil.normalize(new Vertex(x,y,0));
		}
	}
	
	boolean pressed[] = new boolean[100];
	public void keys() {
		Vertex m = new Vertex(0,0,0);
		if(pressed(17)) {
			m = MathUtil.add(new Vertex(1,0,0), m);
		}
		if(pressed(30)) {
			m = MathUtil.add(new Vertex(0,1,0), m);
		}
		if(pressed(31)) {
			m = MathUtil.add(new Vertex(-1,0,0), m);
		}
		if(pressed(32)) {
			m = MathUtil.add(new Vertex(0,-1,0), m);
		}		
		double d = Math.abs(m.x + m.y);
		if(d != 0) {
			m.x = m.x/d;
			m.y = m.y/d;
		}
		movement(m);
		
		if(pressed(1) & !pressed[1]) {
			int i = 0;
			boolean b = false;
			while(i < game.engine.ui.menuItems.length) {
				if(game.engine.ui.menuItems[i])
					b = true;
				i++;
			}
			if(b)
				game.engine.ui.hideAll();
			else
				game.engine.ui.menuItems[0] = true;
			pressed[1] = true;
		}
		if(!pressed(1) & pressed[1])
			pressed[1] = false;
		
		if(pressed(15) & !pressed[15]) {
			weaponNext();
			pressed[15] = true;
		}
		if(!pressed(15) & pressed[15])
			pressed[15] = false;
		
		if(pressed(18) & !pressed[18]) {
			pickup();
			pressed[18] = true;
		}
		if(!pressed(18) & pressed[18])
			pressed[18] = false;
		
		if(pressed(36) & !pressed[36]) {
			if(pawn != null)
				if(pawn.weapon != null)
					drop(pawn.weapon.nid);
			pressed[36] = true;
		}
		if(!pressed(36) & pressed[36])
			pressed[36] = false;
		
		if(pressed(24) & !pressed[24]) {
			if(pawn != null)
				System.out.println("vertex<REQUIREDINFORMATION>" + pawn.location.x + "," + pawn.location.y + "," + (pawn.location.z + 3));
			pressed[24] = true;
		}
		if(!pressed(24) & pressed[24])
			pressed[24] = false;
		
		if(pressed(25) & !pressed[25]) {
			game.engine.ui.menuItems[6] = !game.engine.ui.menuItems[6];
			pressed[25] = true;
		}
		if(!pressed(25) & pressed[25])
			pressed[25] = false;
		
		if(rmb & !pressed[33]) {
			equipmentUse();
			pressed[33] = true;
		}
		if(!rmb & pressed[33])
			pressed[33] = false;
		
		if(pressed(34) & !pressed[34]) {
			equipmentNext();
			pressed[34] = true;
		}
		if(!pressed(34) & pressed[34])
			pressed[34] = false;
		
		if(pressed(57) & !pressed[57]) {
			jump();
			pressed[57] = true;
		}
		if(!pressed(57) & pressed[57])
			pressed[57] = false;	
	}
	
	public boolean pressed(int k) {
		int i = 0;
		while(i < keys.size()) {
			if(keys.get(i) == k)
				return true;
			i++;
		}
		return false;
	}
	
	public void movement(Vertex a) {
		if(pawn != null)
			pawn.movement(a);
	}
	
	public Item pick = null;
	public void interact() {
		int i = 0;
		pick = null;
		while(i < game.actors.size()) {
			if(game.actors.get(i).getType().contains("i"))
				if(((Item)game.actors.get(i)).owner == null)
					if(MathUtil.length(pawn.location, game.actors.get(i).location) < 4) {
						pick = (Item)game.actors.get(i);
					}
			i++;
		}
	}
	
	public void jump() {
		if(pawn != null)
			pawn.jump();
	}
	
	public void pickup() {
		if(pick != null && pawn != null) {
			game.engine.network.packetsOut.add(new Packet32Pickup(pawn.nid, pick.nid));
		}
	}
	
	public void drop(int i) {
		if(pawn != null) {
			game.engine.network.packetsOut.add(new Packet33Drop(pawn.nid, i));
		}
	}
	
	public void equipmentUse() {
		if(pawn != null) {
			pawn.useEquipment();
		}
	}
	
	public void equipmentNext() {
		if(pawn != null) {
			pawn.equipmentCycleNext();
		}
	}
	
	public void weaponNext() {
		if(pawn != null) {
			pawn.weaponCycleNext();
		}
	}
	
	public void camera() {
		if(pawn != null) {
			if(pawn.fp) {
				cameraLocation = MathUtil.inverse(pawn.location.copy());
				cameraLocation.z -= pawn.eye;
			}
			else {
				cameraLocation = MathUtil.inverse(pawn.location.copy());
				cameraLocation.x += 5;
				cameraLocation.y += 15;
				cameraLocation.z -= 10;
			}
		}
		else {
			cameraLocation = new Vertex(0,0,0);
		}
		GraphicsCore.tran.x = cameraLocation.x;
		GraphicsCore.tran.y = cameraLocation.y;
		GraphicsCore.tran.z = cameraLocation.z;
		game.engine.graphics.cameraVector((float)cameraRotation.x, (float)cameraRotation.y);
		cameraRotation.x=0;
		cameraRotation.y=0;

	}
	
	public void givePawn(Pawn p) {
		p.fp = true;
		p.phys = true;
		pawn = p;
	}
}
