package twelveengine.actors;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet10Instantiate;
import twelvelib.net.packets.Packet40Damage;
import twelveutil.MathUtil;

public class Weapon extends Item {
	
	public boolean simulatedProjectile;
	
	public boolean primary = false;
	public boolean secondary = false;
	
	public String primaryFile;
	public String secondaryFile;
	public ArrayList<String> primaryCache;
	public ArrayList<String> secondaryCache;
	
	public int rof;
	
	public double impulse;
	public int projectiles;
	
	public Vertex spread;
	
	public int shotCount = 0;
	public int shotTimer = 0;
	
	public Weapon(Game w, int n, String m, String p, String s) {
		super(w, n, m);
		simulatedProjectile = false;
		rof = 30;
		impulse = 30;
		projectiles=1;
		spread = new Vertex(0,0,0);
		primaryFile = p;
		secondaryFile = s;
		if(!p.equals(""))
			primaryCache = cacheObject(p);
		if(!s.equals(""))
			secondaryCache = cacheObject(p);
	}
	
	public ArrayList<String> cacheObject(String o) {
		ArrayList<String> file = new ArrayList<String>();
	    try {
			String currentLine;
			DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(o));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
	
		    currentLine=fileReader.readLine();
		    while(!currentLine.equals("%EOF")) {
		    	file.add(currentLine);
			    currentLine=fileReader.readLine();
		    }
		    return file;
	    }
	    catch(Exception e) {
		    return null;
	    }
	}
	
	public void step() {
		if(owner == null) {
			move();
		}
	}
	
	public void equipStep(Biped b) {
		cooldown();
		if(primary)
			primaryTrigger(b);
	}
	
	public void cooldown() {
		if(shotTimer > 0)
			shotTimer--;
	}
	
	public void primaryTrigger(Biped b) {
		if(shotTimer == 0) {
			primaryFire(b);
			shotTimer = rof;
		}
	}
	
	public void primaryFire(Biped b) {
		try {
			int i = 0;
			while(i < projectiles) {
				Vertex r = new Vertex((Math.random()*spread.y)-(spread.y*0.5),(Math.random()*spread.y)-(spread.y*0.5),(Math.random()*spread.x)-(spread.x*0.5));
				Vertex d = MathUtil.multiply(MathUtil.add(MathUtil.normalize(b.look), r), impulse);
				Vertex l = b.location.copy();
				l.z += b.eye;
				if(simulatedProjectile) {
						Actor a = game.createObject(primaryCache, -1, l, d, new Vertex(0,0,0));
						Actor hit = null;
						double damage = 0;
						if(a.getType().contains("h")) {
							Hitscan h = (Hitscan) a;
							h.hit = h.shotTrace(b);
							if(h.hit != null) {
								hit = h.hit;
								damage = h.damage;
							}
						}
						a.file = primaryFile;
						game.addSimulatedObject(a);
						if(hit != null)
							game.engine.network.packetsOut.add(new Packet40Damage(owner.nid, hit.nid, damage));
				}
				else {
					game.engine.network.packetsOut.add(new Packet10Instantiate(-1, primaryFile, l.x, l.y, l.z, d.x, d.y, d.z, 0, 0, 0));
				}
				i++;
			}
		}
		catch(Exception e) {
			System.err.println("FAILED TO READ CACHE OR READ PACKET " + primaryFile);
			e.printStackTrace();
		}
	}
	
	public void drawEquipped() {	
		drawUpdate();
		model.draw();
	}
	
	public String getType() {
		return "iw";
	}
	
	public String toString() {
		return "Weapon:" + name + ":" + nid;
	}
}