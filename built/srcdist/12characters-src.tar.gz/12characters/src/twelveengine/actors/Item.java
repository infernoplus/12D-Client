package twelveengine.actors;

import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.PhysTriangle;
import twelveengine.data.Vertex;
import twelveengine.graphics.Model;
import twelveutil.MathUtil;

public class Item extends Actor {
	public String file;
	
	public Actor owner;
	
	public Model model;
	
	public double drag = 0.96;
	
	public Item(Game w, int n, String m) {
		super(w, n);
		owner = null;
		model = new Model(location, 1, m);
	}
	
	public void step() {
		if(owner == null) {
			move();
		}
	}
	
	public void move() {
		push(new Vertex(0,0,-0.3));
		setVelocity(MathUtil.multiply(velocity, drag));
		int i = 0;
		double t = MathUtil.magnitude(velocity);
		while((i == 0 || t > 0) && i < 10) {
			Vertex recvel = MathUtil.multiply(MathUtil.normalize(velocity), t);
			Collision c = game.bsp.collidePoint(location, recvel);
			if(c != null) {
				double d = dampen(velocity, c.t);
				setVelocity(MathUtil.multiply(MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
				setLocation(c.p);
				t -= c.d;
			}
			else {
				move(recvel);
				t = 0;
			}
			i++;
		}
	}
	
	
	public double dampen(Vertex v, PhysTriangle t) {
		double d = MathUtil.normalSteep(MathUtil.normalize(MathUtil.inverse(v)), t);
		return d;
	}
	
	public String toString() {
		return "Item:" + name + ":" + nid;
	}
	
	public String getType() {
		return "i";
	}
	
	public void drawUpdate() {
		model.move(location);
		model.rotate(rotation);
	}
	
	public void draw() {	
		if(owner == null) {
			drawUpdate();
			model.draw();
		}
	}
}
