package twelveengine.actors;

import static org.lwjgl.opengl.GL11.GL_LIGHTING;
import static org.lwjgl.opengl.GL11.GL_LINES;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glVertex3d;
import twelveengine.Game;
import twelveengine.data.Vertex;
import twelveutil.MathUtil;

public class Pawn extends Biped {
	
	public double moveSpeed;
	public double airControl;
	
	public boolean fp = false;
	
	public Pawn(Game w, int n, String m, String p) {
		super(w, n, m, p);
		
		moveSpeed = 0.7;
		airControl = 0.05;
	}
	
	public void movement(Vertex a) {
		if(onGround) {
			Vertex m = new Vertex(0,0,0);
			m = MathUtil.add(m, moveOnLookX(move, a.x));
			m = MathUtil.add(m, moveOnLookY(move, a.y));
			m = MathUtil.multiply(MathUtil.normalize(m), moveSpeed);
			push(m);
		}
		else {		
			Vertex m = new Vertex(0,0,0);
			m = MathUtil.add(m, moveOnLookX(move, a.x));
			m = MathUtil.add(m, moveOnLookY(move, a.y));
			m = MathUtil.multiply(MathUtil.multiply(MathUtil.normalize(m), moveSpeed), airControl);
			push(m);
		}
	}
	
	public Vertex moveOnLookX(Vertex b, double d) {
		Vertex c = MathUtil.normalize(MathUtil.multiply(b, new Vertex(d,d,d)));
		return c;
	}
	
	public Vertex moveOnLookY(Vertex b, double d) {
		Vertex e = new Vertex(-b.y, b.x, b.z);
		Vertex c = MathUtil.normalize(MathUtil.multiply(e, new Vertex(d,d,d)));
		return c;
	}
	
	public String getType() {
		return "bp";
	}
	
	public void draw() {
		if(fp) {
			glDisable(GL_LIGHTING);
			glDisable(GL_TEXTURE_2D);
			glBegin(GL_LINES);
			glColor3f(0.0f,0.0f,1.0f); 
			glVertex3d(location.x, location.y, location.z);
			glVertex3d(location.x, location.y, location.z-foot);
			
			glVertex3d(aa.x, aa.y, aa.z);
			glVertex3d(bb.x, bb.y, bb.z);
			glEnd();
			glEnable(GL_LIGHTING);
			glEnable(GL_TEXTURE_2D);
		}
		else {
			drawUpdate();
			model.draw();
			
			if(weapon != null) {
				weapon.drawEquipped();
			}
			
			glDisable(GL_LIGHTING);
			glDisable(GL_TEXTURE_2D);
			glBegin(GL_LINES);
			glColor3f(0.0f,0.0f,1.0f); 
			glVertex3d(location.x, location.y, location.z);
			glVertex3d(location.x, location.y, location.z-foot);
			
			glVertex3d(aa.x, aa.y, aa.z);
			glVertex3d(bb.x, bb.y, bb.z);
			glColor3f(1.0f,0.0f,0.0f); 
			glVertex3d(location.x, location.y, location.z+eye);
			glVertex3d(location.x + (look.x*10), location.y + (look.y*10), location.z + (look.z*10));
			glEnd();
			glEnable(GL_LIGHTING);
			glEnable(GL_TEXTURE_2D);
		}
	}
	
}
