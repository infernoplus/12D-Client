package twelveengine.actors;

import static org.lwjgl.opengl.GL11.GL_LIGHTING;
import static org.lwjgl.opengl.GL11.GL_LINES;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glVertex3d;
import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.Vertex;
import twelveutil.MathUtil;

public class Hitscan extends Actor {

	public Actor hit;
	
	public int lifeSpan;
	
	public double damage;
	
	public Hitscan(Game w, int n, int s) {
		super(w, n);
		hit = null;
		lifeSpan = s;
		damage = 0;
	}
	
	public void step() {
		if(lifeSpan > 0)
			lifeSpan--;
		else
			dead = true;
	}
	
	public Actor shotTrace(Actor exclude) {
		Collision b = game.bsp.collidePoint(location, velocity);
		Collision a = collideActorsPoint(location, velocity, exclude);
		if(a != null && b != null) {
			if(a.d <= b.d) {
				velocity = a.p;
				return a.a;
			}
			if(a.d > b.d) {
				velocity = b.p;
				return null;
			}
		}
		else {
			if(a != null) {
				velocity = a.p;
				return a.a;
			}
			if(b != null) {
				velocity = b.p;
				return null;
			}
		}
		velocity = MathUtil.add(location, velocity);
		return null;
	}
	
	public Collision collideActorsPoint(Vertex a, Vertex b, Actor exclude) {
		int i = 0;
		int j = 0;
		Actor collideable;
		Collision c = null;
		while(j < game.actors.size()) {
			if(game.actors.get(j).collision != null && game.actors.get(j) != exclude) {
				collideable = game.actors.get(j);
				while(i < collideable.collision.f.length) {
					Collision d = MathUtil.lineTriangleIntersection(a, b, collideable.collision.f[i].move(collideable.collision.location));
					if(d != null) {
						if(c != null) {
							if(d.d <= c.d) {
								c = d;
								c.a = collideable;
								
							}
						}
						else {
							c = d;
							c.a = collideable;
						}
					}
					i++;
				}
			}
			i=0;
			j++;
		}
		return c;
	}
	
	public String getType() {
		return "h";
	}

	public void draw() {
		if(lifeSpan > 0) {
			glDisable(GL_LIGHTING);
			glDisable(GL_TEXTURE_2D);
			glBegin(GL_LINES);
			glColor3f(1.0f,1.0f,0.0f); 
			glVertex3d(location.x, location.y, location.z-0.5);
			glVertex3d(velocity.x, velocity.y, velocity.z);
			glEnd();
			glEnable(GL_LIGHTING);
			glEnable(GL_TEXTURE_2D);
		}
	}
}