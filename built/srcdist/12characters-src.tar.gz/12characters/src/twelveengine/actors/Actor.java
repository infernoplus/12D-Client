package twelveengine.actors;

import static org.lwjgl.opengl.GL11.*;

import twelveengine.Game;
import twelveengine.data.PhysModel;
import twelveengine.data.Vertex;
import twelveutil.MathUtil;

public class Actor {
	public Game game;
	
	public String file;
	public String name;
	public int nid;
	
	public PhysModel collision;
	
	public boolean dead;
	
	public int team;
	
	public Vertex location;
	public Vertex rotation;
	public Vertex velocity;
	
	public double radius;
	
	public boolean phys = false;
	
	//NEVER INSTANTIATE AN ACTOR OR ACTOR SUBCLASS MANUALLY / use engine.game.addObject(); Actor classes are just template for a tag like assets/object/character/generic to fill out and become an object in the world through
	public Actor(Game w, int n) {
		game = w;
		nid = n;
		file = "null";
		name = "null";
		team = -1;
		collision = null;
		dead = false;
		location = new Vertex(0,0,0);
		rotation = new Vertex(0,0,0);
		velocity = new Vertex(0,0,0);
		radius = 1;
	}
	
	public void step() {
		
	}
	
	public void move(Vertex a) {
		location = MathUtil.add(location, a);
	}
	
	public void rotate(Vertex a) {
		rotation = MathUtil.add(rotation, a);
	}
	
	public void push(Vertex a) {
		velocity = MathUtil.add(velocity, a);
	}
	
	public void setLocation(Vertex a) {
		location = a;
	}
	
	public void setRotation(Vertex a) {
		rotation = a;
	}
	
	public void setVelocity(Vertex a) {
		velocity = a;
	}
	
	public void damage(double d, Actor a) {
		
	}
	
	public String getName() {
		return name;
	}
	
	public String toString() {
		return "Actor:" + name + ":" + nid;
	}
	
	public String getType() {
		return "";
	}
	
	public void draw() {	
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_POINTS);
		glColor3f(1.0f,1.0f,1.0f); 
		glVertex3d(location.x, location.y, location.z);
		glEnd();
		glEnable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
	}
}
