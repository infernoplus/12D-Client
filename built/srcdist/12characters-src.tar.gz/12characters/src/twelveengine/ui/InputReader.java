/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersengines.com/
 * 
 * InputReader
 * Reads input and affects the engine state accordingly.
 */

package twelveengine.ui;

import java.util.ArrayList;

import org.lwjgl.input.Mouse;

import de.matthiasmann.twl.Event;

import twelveengine.Engine;

public class InputReader {
	
	public static ArrayList<Integer> keys = new ArrayList<Integer>();
	public static int x;
	public static int y;
	
	public static boolean readInput(Engine engine, Event evt) {
		if(evt.isKeyEvent()) {
			if(evt.isKeyPressedEvent()) {
				int i = 0;
				boolean b = true;
				while(i < keys.size()) {
					if(evt.getKeyCode() == keys.get(i)) {
						b = false;
					}
					i++;
				}
				if(b) {
					keys.add(evt.getKeyCode());
				}
			}
			else {
				int i = 0;
				while(i < keys.size()) {
					if(evt.getKeyCode() == keys.get(i)) {
						keys.remove(i);
						i--;
					}
					i++;
				}
			}
		}
		
		engine.console.readMouse(Mouse.isButtonDown(0), Mouse.isButtonDown(1), Mouse.isButtonDown(2), x - Mouse.getX(), y - Mouse.getY());
		engine.console.readKeyboard(keys);
	
		Mouse.setCursorPosition(engine.graphics.displayWidth/2, engine.graphics.displayHeight/2);
			
		x = Mouse.getX();
		y = Mouse.getY();
	
		return evt.isMouseEventNoWheel();
	}
}