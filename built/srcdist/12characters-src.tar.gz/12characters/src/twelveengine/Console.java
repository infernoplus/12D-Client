/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersgames.com/
 * 
 * Console
 * Modifies the game state based on command Strings.
 */

package twelveengine;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Console {
	
	Engine engine;
	
	public Console(Engine passedGame) {
		System.out.println("Initializing console...");
		engine = passedGame;
		System.out.print("Executing config.cfg...");
		try {
			DataInputStream fileIn = new DataInputStream(new FileInputStream("config.cfg"));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
		    try {
		    	while (true)
		    		read(fileReader.readLine());
		    } catch (Exception e){};
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	    System.out.println(" Done!");
		System.out.println("Console initialized!");
	}
	
	public void readKeyboard(ArrayList<Integer> a) {
		if(engine.game.player != null) {
			engine.game.player.readKey(a);
		}
	}
	
	public void readMouse(boolean a, boolean b, boolean c, int x, int y) {
		if(engine.game.player != null) {
			engine.game.player.readMouse(a, b, c, x, y);
		}
	}
	
	public void read(String command) {
		int firstSpace = command.indexOf(" ");
		if (firstSpace > -1)
			readMultiArgs(command.substring(0, firstSpace), command.substring(firstSpace + 1));
		else
			readSingleArg(command);
	}
	
	private void readMultiArgs(String argOne, String parameter) {
		if (argOne.equals("musicVolume")) {
			try {
				if (Integer.parseInt(parameter) > 100 || Integer.parseInt(parameter) < 0)
					throw new Exception();
				if (engine.audio != null)
					engine.audio.setMusicVolume(Integer.parseInt(parameter));
				Settings.musicVolume = Integer.parseInt(parameter);
			} catch(Exception e) {
				e.printStackTrace();
				System.out.println("musicVolume: 0-100");
			}
		}
		else if (argOne.equals("soundVolume")) {
			try {
				if (Integer.parseInt(parameter) > 100 || Integer.parseInt(parameter) < 0)
					throw new Exception();
				if (engine.audio != null)
					engine.audio.setSoundVolume(Integer.parseInt(parameter));
				Settings.soundVolume = Integer.parseInt(parameter);
			} catch(Exception e) {
				System.out.println("soundVolume: 0-100");
			}
		}
		else if (argOne.equals("displayWidth")) {
			try {
				if (Integer.parseInt(parameter) <= 0)
					throw new Exception();
				Settings.displayWidth = Integer.parseInt(parameter);
			} catch(Exception e) {
				System.out.println("displayWidth: >0");
			}
		}
		else if (argOne.equals("displayHeight")) {
			try {
				if (Integer.parseInt(parameter) <= 0)
					throw new Exception();
				Settings.displayHeight = Integer.parseInt(parameter);
			} catch(Exception e) {
				System.out.println("displayHeight: >0");
			}
		}
		else if (argOne.equals("enableFullscreen")) {
			try {
				Settings.enableFullscreen = Boolean.parseBoolean(parameter);
			} catch(Exception e) {
				System.out.println("enableFullscreen: true/false");
			}
		}
		else if (argOne.equals("enableVSync")) {
			try {
				Settings.enableVSync = Boolean.parseBoolean(parameter);
			} catch(Exception e) {
				System.out.println("enableVSync: true/false");
			}
		}

	}	
	
	private void readSingleArg(String arg) {
		if (arg.equals("quit"))
			engine.stopRuntime = true;
		else if (arg.equals("toggleMenu"))
			engine.toggleMenu();
		else if (arg.equals("quit"))
			engine.stopRuntime = true;
	}
}
