package twelveengine.graphics;

import static org.lwjgl.opengl.GL11.*;

public class Origin {
	private double scale;
	
	public Origin(double s) {
		scale = s;
	}
	
	public void draw() {
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_LINES);
		glColor3d(1.0, 0.0,0.0);          
		glVertex3d(0.0, 0.0, 0.0);
		glVertex3d(scale, 0.0, 0.0);
		glColor3d(0.0,1.0,0.0);          
		glVertex3d(0.0, 0.0, 0.0);
		glVertex3d(0.0, scale, 0.0);
		glColor3d(0.0,0.0,1.0);          
		glVertex3d(0.0, 0.0, 0.0);
		glVertex3d(0.0, 0.0, scale);
		glEnd();
		glEnable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
	}
}