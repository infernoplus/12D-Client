/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersengines.com/
 * 
 * GraphicsCore
 * Renders window and calls Core methods designated to perform specific graphics rendering.
 */

package twelveengine.graphics;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.util.glu.GLU;

import static org.lwjgl.opengl.GL11.*;

import twelveengine.Engine;
import twelveengine.Settings;
import twelveengine.data.Vertex;

public class GraphicsCore {
	
	/** Passed Engine Instance */
	private Engine engine;
	
	public static Vertex tran = new Vertex(0,0,0);
	public static Vertex rot = new Vertex(0,0,0);
	/** Some necessary graphics files. */
	/** Display Settings */
	public int displayWidth;
	public int displayHeight;
	private boolean enableFullscreen;
	private boolean enableVSync;
	/** This is used to "zoom" on the player depending on screen resolution */

	int colorTextureID;
	int framebufferID;
	int depthRenderBufferID;
	
	/** Constructor for the GraphicsCore. Sets up the Display and initializes OpenGL.
	 * @param passedGame The Engine instance
	 */
	public GraphicsCore(Engine passedGame) {
		System.out.println("\nInitializing Graphics...");
		engine = passedGame;
		displayWidth = Settings.displayWidth;
		displayHeight = Settings.displayHeight;
		enableFullscreen = Settings.enableFullscreen;
		enableVSync = Settings.enableVSync;
		// Create/Start Display
		System.out.println("Initializing Display...");
		try {
		    Display.setTitle(engine.gameTitle);
	    	if (enableFullscreen) {
		    	displayWidth = Display.getDesktopDisplayMode().getWidth();
		    	displayHeight = Display.getDesktopDisplayMode().getHeight();
		    	Display.setDisplayMode(Display.getDesktopDisplayMode());
		    	Display.setFullscreen(enableFullscreen);
		    } else
		    	Display.setDisplayMode(new DisplayMode(displayWidth,displayHeight));
			Display.setVSyncEnabled(enableVSync);	
			Display.create();
			System.out.println("Loaded OpenGL device: " + glGetString(GL_RENDERER));
			System.out.println("OpenGL Version/Driver: " + glGetString(GL_VERSION));
			System.out.println("OpenGL Vendor: " + glGetString(GL_VENDOR));
			System.out.println("Display started!");
		} catch (LWJGLException e) {
		    e.printStackTrace();
		    System.exit(0);
		}
		System.out.println("Loading some graphics files...");
		System.out.println("... Loaded!");
		// Create OpenGL stuff
		System.out.print("Initializing OpenGL features...");		
		glViewport (0, 0, displayWidth, displayHeight);								// Reset The Current Viewport
		glMatrixMode (GL_PROJECTION);								// Select The Projection Matrix
		glLoadIdentity ();											// Reset The Projection Matrix
		GLU.gluPerspective (90.0f, displayWidth/displayHeight, 0.1f, 10000.0f);		// Calculate The Aspect Ratio Of The Window	
		glMatrixMode (GL_MODELVIEW);								// Select The Modelview Matrix
		glLoadIdentity ();											// Reset The Modelview Matrix
		

		glClearColor (0.0f, 0.0f, 0.0f, 0.0f);						// Black Background
		glEnable(GL_BLEND);
		glEnable(GL_LIGHTING);
		glClearDepth (1.0f);										// Depth Buffer Setup
		glDepthFunc (GL_LEQUAL);									// The Type Of Depth Testing (Less Or Equal)
		glEnable (GL_DEPTH_TEST);									// Enable Depth Testing
		glShadeModel (GL_SMOOTH);									// Select Smooth Shading
		glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		
		   glEnable (GL_LINE_SMOOTH);
		
		glHint (GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);			// Set Perspective Calculations To Most Accurate
		glHint (GL_POINT_SMOOTH_HINT, GL_NICEST);	
		glHint (GL_LINE_SMOOTH_HINT, GL_NICEST);	
		glHint (GL_POLYGON_SMOOTH_HINT, GL_NICEST);	
		
		
		
		System.out.println(" Done!");
		System.out.println("Graphics started!");
	}
	
	/** Destroys the engine Display. */
	public void endGraphics() {
		System.out.print("Removing some graphics files from memory...");
		System.out.println(" Done!");
		System.out.print("Stopping Display...");
		Display.destroy();
		System.out.println(" Stopped!");
	}
	
	/** Draws all of the graphics as specified by the settings and current context. */
	public void renderGraphics() {		
		glClearColor (0f, 0f, 0f, 1f);
	
		//Game
		glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glViewport(0, 0, displayWidth, displayHeight);
		glLoadIdentity();
		glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
		
		glRotated(rot.x,1.0,0.0,0.0);
		glRotated(rot.y,0.0,1.0,0.0);
		glRotated(rot.z,0.0,0.0,1.0);
		glTranslated(tran.x, tran.y, tran.z);								

		
		engine.game.drawGame();
		
		glFlush ();
		
		//HUD TODO: currently just drawing a crosshair, create actual hud
		glLoadIdentity();
		glRotated(0,1.0,0.0,0.0);
		glRotated(0,0.0,1.0,0.0);
		glRotated(0,0.0,0.0,1.0);
		glTranslated(0, 0, -0.1);
		
		glLineWidth(0.1f);
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_LINES);
		glColor3d(1.0, 1.0, 1.0);          
		glVertex3d(-0.001, -0.001, 0.0);
		glVertex3d(0.001, 0.001, 0.0);  
		glVertex3d(-0.001, 0.001, 0.0);
		glVertex3d(0.001, -0.001, 0.0);
		glEnd();
		glEnable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
		
		engine.ui.update();
	    Display.update();
	    if (Display.isCloseRequested())
	    	engine.stopRuntime = true;
	}
	
	public void cameraVector(float xx, float yy) {
		rot.x -= yy;
		rot.y = 0;
		rot.z -= xx;
		
		if(rot.x <= -180)
			rot.x = -180;
		if(rot.x >= 0)
			rot.x = 0;
		
		if(rot.z <= -360)
			rot.z += 360;
		if(rot.z >= 360)
			rot.z -= 360;
	}
	
	public int zoom = 1000;
	public void zoomHandle(int i) {
		zoom = zoom + i*50;
		if(zoom < 10)
			zoom = 10;
		if(zoom > 10000)
			zoom = 10000;
	}
	
	public void listenMouse() {
		
	}
	
	/** Sets the "zoom" on the player depending on screen resolution */
}