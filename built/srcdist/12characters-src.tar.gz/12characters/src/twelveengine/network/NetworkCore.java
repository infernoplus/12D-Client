package twelveengine.network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import twelveengine.Engine;
import twelveengine.actors.Actor;
import twelveengine.actors.Biped;
import twelveengine.actors.Equipment;
import twelveengine.actors.Pawn;
import twelveengine.actors.Weapon;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet0Handshake;
import twelvelib.net.packets.Packet10Instantiate;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;
import twelvelib.net.packets.Packet13Push;
import twelvelib.net.packets.Packet17Equipment;
import twelvelib.net.packets.Packet1Join;
import twelvelib.net.packets.Packet20Control;
import twelvelib.net.packets.Packet31Inventory;
import twelvelib.net.packets.Packet34Equip;
import twelvelib.net.packets.Packet3Login;
import twelvelib.net.packets.Packet40Damage;
import twelvelib.net.packets.Packet42Health;
import twelvelib.net.packets.Packet49Message;
import twelvelib.net.packets.Packet4Load;
import twelvelib.net.packets.Packet5Heartbeat;
import twelvelib.net.packets.Packet9Destroy;

public class NetworkCore {
	public Engine engine;
	
	public ClientConnection connection;
	
	public ArrayList<Packet> packetsOut = new ArrayList<Packet>();
	public ArrayList<Packet> packetsIn = new ArrayList<Packet>();

	public NetworkCore(Engine a) {
		engine = a;
		hbLast = engine.getTime();
	}
	
	public int hbTime = 5000;
	public long currentTime;
	public long hbLast;
	public void step() {
		if(connection != null) {
			//Heartbeat
			if(connection != null) {
		    	currentTime = engine.getTime();
				if (currentTime - hbLast > hbTime) {
					connection.sendPacket(new Packet5Heartbeat());
					hbLast = currentTime;
				}
			}
			//In packets
			while(packetsIn.size() > 0) {
				parse(packetsIn.get(0));
				packetsIn.remove(0);
			}
			//Net step
			engine.game.netStep();
			//Out packets
			while(packetsOut.size() > 0) {
				Packet p = packetsOut.get(0);
				connection.sendPacket(p);
				packetsOut.remove(0);
			}
		}
	}
	
	public void parse(Packet p) {
		try {
			if(p.packetType() == 4)
				packet4(p);
			if(p.packetType() == 9)
				packet9(p);
			if(p.packetType() == 10)
				packet10(p);
			if(p.packetType() == 11)
				packet11(p);
			if(p.packetType() == 12)
				packet12(p);
			if(p.packetType() == 13)
				packet13(p);
			if(p.packetType() == 17)
				packet17(p);
			if(p.packetType() == 20)
				packet20(p);
			if(p.packetType() == 31)
				packet31(p);
			if(p.packetType() == 34)
				packet34(p);
			if(p.packetType() == 40)
				packet40(p);
			if(p.packetType() == 42)
				packet42(p);
			if(p.packetType() == 49)
				packet49(p);
		}
		catch(Exception e) {
			System.err.println("Failed to parse packet #" + p.packetType() + "!");
			e.printStackTrace();
		}
	}
	
	public void packet4(Packet p) {
		Packet4Load l = (Packet4Load) p;
		engine.loadGame(l.scenario);
	}
	
	public void packet9(Packet p) {
		Packet9Destroy d = (Packet9Destroy) p;
			engine.game.removeActor(d.nid);
	}
	
	public void packet10(Packet p) {
		Packet10Instantiate i = (Packet10Instantiate) p;
		engine.game.addObject(i.type, i.nid, new Vertex(i.x,i.y,i.z), new Vertex(i.i, i.j, i.k), new Vertex(i.m,i.n,i.o));
	}
	
	public void packet11(Packet p) {
		Packet11Location l = (Packet11Location) p;
		boolean b = true;
		if(engine.game.player.pawn != null)
			if(l.nid == engine.game.player.pawn.nid)
				b = false;
		if(l.force) {
			b= true;
		}
		if(b) {
			Actor a = engine.game.getActor(l.nid);
			if(a != null) {
				a.setLocation(new Vertex(l.x, l.y, l.z));
				a.setVelocity(new Vertex(l.i, l.j, l.k));
			}
		}		
	}
	
	public void packet12(Packet p) {
		Packet12Rotation r = (Packet12Rotation) p;
		boolean b = true;
		if(engine.game.player.pawn != null)
			if(r.nid == engine.game.player.pawn.nid)
				b = false;
		if(r.force)
			b= true;
		if(b) {
			Actor a = engine.game.getActor(r.nid);
			if(a != null)
				a.setRotation(new Vertex(r.x, r.y, r.z));
		}
	}
	
	public void packet13(Packet p) {
		Packet13Push u = (Packet13Push) p;
		Actor a = engine.game.getActor(u.nid);
		if(a != null)
			a.push(new Vertex(u.x, u.y, u.z));
	}
	
	public void packet17(Packet p) {
		Packet17Equipment e = (Packet17Equipment) p;
		Actor a = engine.game.getActor(e.equip);
		if(a != null)
			if(a.getType().contains("e")) {
				((Equipment)a).total = e.total;
			}
	}
	
	public void packet20(Packet p) {
		Packet20Control c = (Packet20Control) p;
		Actor a = engine.game.getActor(c.nid);
		if(a != null) {
			try {
				engine.game.player.givePawn((Pawn) a);
			}
			catch(Exception e) {
				System.err.println("Failed to give player control to: " + a.toString());
			}
		}
		else {
			packetsIn.add(p);
		}
	}
	
	public void packet31(Packet p) {
		Packet31Inventory i = (Packet31Inventory) p;
		Actor a = engine.game.getActor(i.owner);
		if(a != null)
			if(a.getType().contains("b"))
				((Biped)a).inventoryUpdate(i.items);
	}
	
	public void packet34(Packet p) {
		Packet34Equip e = (Packet34Equip) p;
		if(e.item == -1) {
			Actor b = engine.game.getActor(e.player);
			((Biped)b).weapon = null;
		}
		else if(e.item == -2) {
			Actor b = engine.game.getActor(e.player);
			((Biped)b).equipment = null;
		}
		else {
			Actor a = engine.game.getActor(e.item);
			Actor b = engine.game.getActor(e.player);
			if(a.getType().contains("w"))
				((Biped)b).weapon = (Weapon)a;
			if(a.getType().contains("e"))
				((Biped)b).equipment = (Equipment)a;
		}
	}
	
	public void packet40(Packet p) {
		Packet40Damage d = (Packet40Damage) p;
		Actor a = engine.game.getActor(d.owner);
		Actor b = engine.game.getActor(d.hit);
		b.damage(d.damage, a);
	}
	
	public void packet42(Packet p) {
		Packet42Health h = (Packet42Health) p;
		Actor a = engine.game.getActor(h.owner);
		((Biped)a).setHealth(h.health);
	}
	
	public void packet49(Packet p) {
		Packet49Message m = (Packet49Message) p;
		engine.ui.addMessage(m.message);
	}
	
    public boolean connect(String ip, int port, String user) {
    	close();
    	String reason = "generic";
		//cm.setText("Trying " + ip + ":" + port + " ...");
		try {
			Socket requestSocket;
			ObjectOutputStream output;
			ObjectInputStream input;
			
			requestSocket = new Socket(ip, port);
			
			output = new ObjectOutputStream(requestSocket.getOutputStream());
			output.flush();
			
			//cm.setText("Waiting on server...");
			
			input = new ObjectInputStream(requestSocket.getInputStream());
			
			//cm.setText("Logging in...");
			output.writeObject(new Packet3Login(user));
			output.flush();
			
			Packet p;
			try {
				p = (Packet) input.readObject();
				
	    		input.close();
	    		output.close();
	    		requestSocket.close();
	    		requestSocket = null;
			
			if(p.packetType() == 0) {		
				Packet0Handshake h = (Packet0Handshake) p;
				if(h.fail) {
					//cm.setText(h.reason);
					return false;
				}
				//cm.setText("Connecting to " + h.serverName + "@" + h.ip  + " on port " + h.port);
				//System.out.println(h.serverName + "@" + ip  + ":" + h.port);
				//System.out.println("MOTD: " + h.serverInfo);
				requestSocket = new Socket(ip, h.port);
				output = new ObjectOutputStream(requestSocket.getOutputStream());
				output.flush();
				
				//cm.setText("Waiting on server...");
				input = new ObjectInputStream(requestSocket.getInputStream());
				p = (Packet) input.readObject();
				if(p.packetType() == 4) {
					Packet4Load l = (Packet4Load) p;
					//cm.setText("Connected! Loading...");
					if(engine.loadGame(l.scenario)) {
						connection = new ClientConnection(this, ip, h.port, user, requestSocket, input, output);
						return true;
					}
					else {
			    		output.writeObject(new Packet1Join(false));
			    		requestSocket.close();
			    		return false;
					}
						
				}
			}		
			} 
			catch (ClassNotFoundException e) {
				//e.printStackTrace();
				reason = e.toString();
			}
		} catch (UnknownHostException e) {
			//e.printStackTrace();
			reason = e.toString();
		} catch (IOException e) {
			//e.printStackTrace();
			reason = e.toString();
		}		
			//cm.setText("Failed to connect to " + ip + ":" + port);
			System.err.println("Reason: " + reason);
			System.out.println("");
    	
    	return false;
    }
    
    public void close() {
    	if(connection != null) {
    		connection.disconnect();
    		connection = null;
    	}
    }
}
