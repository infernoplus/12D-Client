package twelveengine.network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import twelvelib.net.packets.Packet;
import twelvelib.net.packets.Packet1Join;
import twelvelib.net.packets.Packet2Disconnect;

public class ClientConnection extends Thread {
	public NetworkCore network;
	
	public String ip;
	public int port;
	public String user;
	
	public Socket connection;
	public ObjectInputStream in;
	public ObjectOutputStream out;
	
	public boolean disconnect;
	public boolean reading;

	
	public ClientConnection(NetworkCore n, String a, int b, String c, Socket d, ObjectInputStream e, ObjectOutputStream f) {
		network = n;
		ip = a;
		port = b;
		user = c;
		connection = d;
		in = e;
		out = f;
		reading = true;
		disconnect = false;
		start();
	}

	public void run() {
		sendPacket(new Packet1Join(true));
		while(!disconnect) {
			Object o = null;
			Packet p;
			try {
				o = in.readObject();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			  
			try {
				  if(o != null) {
					  p = (Packet) o;
					  if(p != null) {
						  if(p.packetType() == 2)
							  packet2(p);
						  else 
							  network.packetsIn.add(p);
					  }
				}
			} 
			catch (Exception e) {
				System.err.println("Bad packet from client threw exception: " + e.getClass().toString());
				e.printStackTrace();
			}
		}
	}
	
	public void packet2(Packet p) {
		Packet2Disconnect d = (Packet2Disconnect) p;
		System.out.println("Disconnect: " + d.reason);
		network.close();
	}
	
	public synchronized void sendPacket(Packet p) {
		try {
			out.writeObject(p);
			out.flush();
		} catch(Exception e) {
			System.err.println("Failed to send packet:");
		}

	}
	
	public void disconnect() {
		sendPacket(new Packet2Disconnect(user, "Disconnect, client"));
		disconnect = true;
		try {
			out.close();
			in.close();
			connection.close();
		} catch (IOException e) {
			System.err.println("Failed to close connection!");
		}
	}
}








