package twelveengine.actors;

import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.PhysTriangle;
import twelveengine.data.Vertex;
import twelveengine.graphics.Model;
import twelveutil.MathUtil;

public class Projectile extends Actor {
	public String file;
	
	public Actor owner;
	
	public Model model;
	
	public boolean expended = false;
	
	public int life;
	public double drag;
	
	public double damage;
	public double damageRadius;
	public double force;
	
	
	public Projectile(Game w, int n, String m) {
		super(w, n);
		owner = null;
		model = new Model(location, 1, m);
		life = 90;
		drag = 0.96;
		damage = 50;
		damageRadius = 3;
		force = 3;
	}
	
	public void step() {
		if(!expended) {
			move();
			projectile();
		}
	}
	
	//Simulates physics without collision, this is just for when there is no packet and we need a guess at where the next step is.
	public void move() {
		setVelocity(MathUtil.multiply(velocity, drag));
		setLocation(MathUtil.add(location, velocity));
	}
	
	public void projectile() {
		if(life > 0) {
			life--;
		}
		else {
			detonate();
		}
	}
	
	public void detonate() {
		expended = true;
	}
	
	
	public double dampen(Vertex v, PhysTriangle t) {
		double d = MathUtil.normalSteep(MathUtil.normalize(MathUtil.inverse(v)), t);
		return d;
	}
	
	public String toString() {
		return "Projectile:" + name + ":" + nid;
	}
	
	public String getType() {
		return "g";
	}
	
	public void drawUpdate() {
		model.move(location);
		model.rotate(rotation);
	}
	
	public void draw() {	
		if(!expended) {
			if(owner == null) {
				drawUpdate();
				model.draw();
			}
		}
	}
}
