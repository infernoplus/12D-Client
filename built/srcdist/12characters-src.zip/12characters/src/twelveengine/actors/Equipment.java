package twelveengine.actors;

import twelveengine.Game;
import twelveengine.data.Vertex;
import twelvelib.net.packets.Packet10Instantiate;
import twelvelib.net.packets.Packet17Equipment;
import twelveutil.MathUtil;

public class Equipment extends Item {
	public String type;
	public boolean stacks;
	
	public String fileCreateOnUse;
	
	public int total;
	
	public double impulse;
	
	public Equipment(Game w, int n, String m) {
		super(w, n, m);
		type = "none";
		stacks = true;
		total = 1;
		impulse = 10;
	}
	
	public void useEquipment(Biped b) {
		if(total > 0) {
			Vertex v = MathUtil.multiply(MathUtil.normalize(b.look.copy()), impulse);
			game.engine.network.packetsOut.add(new Packet10Instantiate(-1, fileCreateOnUse, b.location.x, b.location.y, b.location.z, v.x, v.y, v.z, 0, 0, 0));
			setTotal(total-1);
		}
	}
	
	public void setTotal(int i) {
		game.engine.network.packetsOut.add(new Packet17Equipment(nid, i));
		total = i;
	}
	
	public String equipmentType() {
		return type;
	}
	
	public String getName() {
		return name + ": " + total;
	}
	
	public String toString() {
		return "Equipment:" + name + ":" + nid;
	}
	
	public String getType() {
		return "ie";
	}
}