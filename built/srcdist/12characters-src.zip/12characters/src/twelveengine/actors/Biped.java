package twelveengine.actors;

import static org.lwjgl.opengl.GL11.GL_LIGHTING;
import static org.lwjgl.opengl.GL11.GL_LINES;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glVertex3d;

import java.util.ArrayList;

import twelveengine.Game;
import twelveengine.data.Collision;
import twelveengine.data.PhysModel;
import twelveengine.data.PhysTriangle;
import twelveengine.data.Vertex;
import twelveengine.graphics.Model;
import twelvelib.net.packets.Packet34Equip;
import twelveutil.MathUtil;

public class Biped extends Actor {
	
	public Vertex move;
	public Vertex look;
	
	public Model model;
	
	public double health;
	
	public Weapon weapon;
	public Equipment equipment;
	int wep = 0;
	int eqp = 0;
	public ArrayList<Item> inventory;
	public ArrayList<Weapon> weapons;
	public ArrayList<Equipment> equipments;
	
	public double drag = 0.96;
	public double friction = 0.7;
	
	public boolean jumping = false;
	public boolean onGround = false;
	public Collision ground = null;
	
	public double eye;
	public double foot;
	
	public double jumpHeight;
	
	public boolean primary = false;
	public boolean secondary = false;
	
	public Biped(Game w, int n, String m, String p) {
		super(w, n);
		model = new Model(location, 1.0, m);
		collision = new PhysModel(location, 1.0, p);
		
		move = new Vertex(0, 1, 0);
		look = new Vertex(0, 1, 0);
		
		health = 100;
		
		foot = 1;
		eye = 3;
		jumpHeight = 1.5;
		
		weapon = null;
		inventory = new ArrayList<Item>();
		weapons = new ArrayList<Weapon>();
	}
	
	public void step() {
		move();
		collision();
		inventory();
		equipment();
	}

	public Vertex aa = new Vertex(0,0,0);
	public Vertex bb = new Vertex(0,0,0);
	public void move() {
		if(phys) {
			int i = 0;
			double t = MathUtil.magnitude(velocity);
			while((i == 0 || t > 0) && i < 10) {
				if(!jumping)
					onGround = onGround();
				else {
					jumping = false;
					onGround = false;
				}
				if(onGround) {
					setVelocity(MathUtil.multiply(velocity, friction));
					t = t * friction;
					Collision u = MathUtil.linePlaneIntersection(location, new Vertex(0, 0,-foot*5), ground.t);
					Collision w = MathUtil.linePlaneIntersection(MathUtil.add(location, velocity), new Vertex(0, 0,-foot*5), ground.t);
					if(u != null && w != null) {
						setVelocity(MathUtil.multiply(MathUtil.normalize(MathUtil.subtract(w.p, u.p)), MathUtil.magnitude(velocity)));
						aa = u.p;
						bb = w.p;
					}
					Collision c = game.bsp.collideSphereIncremental(location, velocity, radius);
					if(c != null) {
						double d = dampen(velocity, c.t);
						setVelocity(MathUtil.multiply(MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
						setLocation(c.p);
						t -= c.d;
						//t = t * d;
					}
					else {
						move(velocity);
						t = 0;
					}
				}
				else {
					push(new Vertex(0,0,-0.3));
					setVelocity(MathUtil.multiply(velocity, drag));
					t = t * drag;
					Collision c = game.bsp.collideSphereIncremental(location, velocity, radius); 
					if(c != null) {
						double d = dampen(velocity, c.t);
						setVelocity(MathUtil.multiply(MathUtil.normalize(c.r), MathUtil.magnitude(velocity)*d));
						setLocation(c.p);
						t -= c.d;
						//t = t * d;
					}
					else {
						move(velocity);
						t = 0;
					}
				}
				onGround = onGround();
				if(onGround) {
					if(velocity.z > 0)
						velocity.z = 0;
					raise();
				}
				i++;
			}
			if(i >= 7)
				System.out.println("ALERT: " + i + " recursions were used in the last physics update. That is abnormally high.");
		}
		else {
			move(velocity);
		}
	}
	
	public void collision() {
		collision.move(location.copy());
	}
	
	public void inventory() {
		int i = 0;
		while(i < inventory.size()) {
			inventory.get(i).setLocation(location.copy());
			i++;
		}
	}
	
	public void equipment() {
		if(weapon == null) {
			int i = 0;
			while(i < inventory.size()) {
				if(inventory.get(i).getType().contains("w")) {
					equipWeapon((Weapon)inventory.get(i));
				}
				i++;
			}
		}
		if(equipment == null) {
			int i = 0;
			while(i < inventory.size()) {
				if(inventory.get(i).getType().contains("e")) {
					equipEquipment((Equipment)inventory.get(i));
				}
				i++;
			}
		}
		if(weapon != null) {
			weapon.primary = primary;
			weapon.secondary = secondary;
			weapon.setLocation(location.copy());
			weapon.equipStep(this);
		}
		if(equipment != null) {
			equipment.setLocation(location.copy());
		}
	}
	
	public boolean onGround() {
		Collision c = game.bsp.onGroundSphere(location, radius, foot);
		if(c != null) {
			ground = c;
			return true;
		}
		else {
			ground = null;
			return false;
		}
	}
	
	public void raise() {
		//double d = foot - ground.d;
		//if(d >= 0.05) {
			//Collision c = game.bsp.collideSphereIncremental(location, new Vertex(0, 0, d), radius);
			//if(c == null) {
				//move(new Vertex(0, 0, d));
			//}
		//}
	}
	
	public double dampen(Vertex v, PhysTriangle t) {
		double d = MathUtil.normalSteep(MathUtil.normalize(MathUtil.inverse(v)), t);
		d = 0.1 + (d * 0.8);
		return d;
	}
	
	public void jump() {
		if(onGround) {
			if(velocity.z < 0)
				setVelocity(new Vertex(velocity.x, velocity.y, 0));
			push(new Vertex(0, 0, jumpHeight*2));
			jumping = true;
		}
	}
	
	public void useEquipment() {
		if(equipment != null)
			equipment.useEquipment(this);
	}
	
	public void equipWeapon(Weapon w) {
		if(w != null)
			game.engine.network.packetsOut.add(new Packet34Equip(w.nid, nid));
		else
			game.engine.network.packetsOut.add(new Packet34Equip(-1, nid));
	}
	
	public void equipEquipment(Equipment e) {
		if(e != null)
			game.engine.network.packetsOut.add(new Packet34Equip(e.nid, nid));
		else
			game.engine.network.packetsOut.add(new Packet34Equip(-2, nid));
	}
	
	public void weaponCycleNext() {
		if(weapons.size() > 0) {
			wep++;
			if(wep >= weapons.size())
				wep = 0;
			equipWeapon(weapons.get(wep));
		}
	}
	
	public void equipmentCycleNext() {
		if(equipments.size() > 0) {
			eqp++;
			if(eqp >= equipments.size())
				eqp = 0;
			equipEquipment(equipments.get(eqp));
		}
	}
	
	public void inventoryUpdate(int newInv[]) {
		int i = 0;
		while(0 < inventory.size()) {
			inventory.get(0).owner = null;
			inventory.remove(0);
		}
		inventory = new ArrayList<Item>();
		while(i < newInv.length) {
			Actor a = game.getActor(newInv[i]);
			if(a != null)
				if(a.getType().contains("i")) {
					Item item = (Item)a;
					item.owner = this;
					inventory.add(item);
			}
			i++;
		}
		equipmentUpdate();
	}
	
	public void equipmentUpdate() {
		if(weapon != null)
			if(!inventoryContains(weapon.nid))
				equipWeapon(null);
		int i = 0;
		weapons = new ArrayList<Weapon>();
		while(i < inventory.size()) {
			if(inventory.get(i).getType().contains("w")) {
				weapons.add(((Weapon)inventory.get(i)));
			}
			i++;
		}
		
		if(equipment != null)
			if(!inventoryContains(equipment.nid))
				equipEquipment(null);
		i = 0;
		equipments = new ArrayList<Equipment>();
		while(i < inventory.size()) {
			if(inventory.get(i).getType().contains("e")) {
				equipments.add(((Equipment)inventory.get(i)));
			}
			i++;
		}
	}
	
	public boolean inventoryContains(int n) {
		int i = 0;
		while(i < inventory.size()) {
			if(inventory.get(i).nid == n)
				return true;
			i++;
		}
		return false;
	}
	
	public String inventoryContents() {
		int i = 0;
		String s = "";
		while(i < inventory.size()) {
			if(inventory.get(i) != null)
				s += (i+1) + ": " + inventory.get(i).getName() + "\n";
			else
				s += (i+1) + ":\n";
			i++;
		}
		return s;
	}
	
	public void setHealth(double h) {
		health = h;
	}
	
	public String toString() {
		return "Biped:" + name + ":" + nid;
	}
	
	public String getType() {
		return "b";
	}
	
	public void drawUpdate() {
		model.move(location);
		model.rotate(rotation);
	}
	
	public void draw() {
		drawUpdate();
		model.draw();
		if(weapon != null) {
			weapon.drawUpdate();
			weapon.draw();
		}
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_LINES);
		glColor3f(0.0f,0.0f,1.0f); 
		glVertex3d(location.x, location.y, location.z);
		glVertex3d(location.x, location.y, location.z-foot);
		
		glVertex3d(aa.x, aa.y, aa.z);
		glVertex3d(bb.x, bb.y, bb.z);
		glEnd();
		glEnable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
	}

}
