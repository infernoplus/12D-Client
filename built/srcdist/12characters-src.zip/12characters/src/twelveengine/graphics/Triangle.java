package twelveengine.graphics;

import static org.lwjgl.opengl.GL11.*;

import twelveengine.data.Vertex;
import twelveengine.graphics.Material;
import twelveengine.graphics.Model;
import twelveutil.MathUtil;

public class Triangle {
	//Triangle coordinates
	public Vertex a, b, c;
	//Triangle normals
	public Vertex i, j, k;
	//Triangle texture coordiantes
	public Vertex u, v, w;
	//Triangle Material
	public Material mat;
	
	public Model model;
	
	public Vertex ar;
	public Vertex br;
	public Vertex cr;
	
	public Vertex ir;
	public Vertex jr;
	public Vertex kr;
	
	public Triangle(Vertex aa, Vertex bb, Vertex cc, Vertex ii, Vertex jj, Vertex kk, Vertex uu, Vertex vv, Vertex ww, Material t, Model m) {
		a = aa;
		b = bb;
		c = cc;
		i = ii;
		j = jj;
		k = kk;
		u = uu;
		v = vv;
		w = ww;
		mat = t;
		model = m;
		update();
	}
	
	//Updates triangle based on model location and rotation
	public void update() {
		ar = MathUtil.add(model.location, MathUtil.rotateVertex(a, model.rotation));
		br = MathUtil.add(model.location, MathUtil.rotateVertex(b, model.rotation));
		cr = MathUtil.add(model.location, MathUtil.rotateVertex(c, model.rotation));
		
		ir = MathUtil.add(model.location, MathUtil.rotateVertex(i, model.rotation));
		jr = MathUtil.add(model.location, MathUtil.rotateVertex(j, model.rotation));
		kr = MathUtil.add(model.location, MathUtil.rotateVertex(k, model.rotation));
	}
	
	//Draws this particular triangle.
	public void draw() {
		mat.glMaterialSet();
		
		glBegin(GL_TRIANGLES);
		glTexCoord3d(u.x, u.y, u.z);
		glNormal3d(ir.x, ir.y, ir.z);
		glVertex3d(ar.x, ar.y, ar.z);


		glTexCoord3d(v.x, v.y, v.z);
		glNormal3d(jr.x, jr.y, jr.z);
		glVertex3d(br.x, br.y, br.z);


		glTexCoord3d(w.x, w.y, w.z);
		glNormal3d(kr.x, kr.y, kr.z);
		glVertex3d(cr.x, cr.y, cr.z);
		glEnd();
		
		/*glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_LINES);
		glColor3f(1.0f,0.0f,0.0f);

		glVertex3d(center.x + normal.x, center.y + normal.y, center.z + normal.z);
		glVertex3d(center.x, center.y, center.z);

		glEnd();
		glEnable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);*/
	}
}
