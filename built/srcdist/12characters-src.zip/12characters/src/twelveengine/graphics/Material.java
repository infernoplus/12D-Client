package twelveengine.graphics;

import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBindTexture;

public class Material {
	public double color[];
	public String material;
	public Texture texture;
	
	public Material(String s) {
		material = s;
		getMaterial(s);
	}
	public void getMaterial(String s) {
		try {
			texture = new Texture(s);
			//System.out.println("Texture " + s + " bound to " + texture.getIndex());
		} catch (Exception e) {
			try {
				//System.out.println("Can't find texture: " + s + ".png , Binding default.png instead.");
				texture = new Texture("default");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	public void glMaterialSet() {
		glBindTexture(GL_TEXTURE_2D, texture.getIndex());
	}
}
