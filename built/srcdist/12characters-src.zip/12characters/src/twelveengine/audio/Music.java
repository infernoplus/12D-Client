/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersgames.com/
 * 
 * Music
 * Each instance carries a music file (FLAC format) and its name.
 */

package twelveengine.audio;

import static org.lwjgl.openal.AL10.*;

import com.flibitijibibo.flibitFile.FLACFile;

public class Music {
	
	/** Music properties */
	private int musicBufferIndex;
	private int musicSourceIndex;
	private String songName;
	
	/** Loads the music into OpenAL and plays it.
	 * @param Level The file name of the music file in assets/audio/music/
	 */
	public Music(String Level, float volume) {
		songName = Level;
		// Load music file
		try {
			FLACFile fileIn = new FLACFile("audio/music/" + Level + ".flac");
			musicBufferIndex = alGenBuffers();
	    	alBufferData(musicBufferIndex, fileIn.getFormat(), fileIn.getData(), fileIn.getSampleRate());
	    	fileIn.dispose();
		} catch (Exception e) {
			e.printStackTrace();
		}
	    // Create source
	    musicSourceIndex = alGenSources();
	    alSourcei(musicSourceIndex, AL_BUFFER, musicBufferIndex);
	    // Set music source properties
	    setVolume(volume);
	    alSourcef(musicSourceIndex, AL_PITCH, 1.0f);
	    alSourcef(musicSourceIndex, AL_MIN_GAIN, 0.01f);
	    alSourcef(musicSourceIndex, AL_MAX_GAIN, 0.01f);
	    alSourcei(musicSourceIndex, AL_LOOPING, AL_TRUE);
	    playMusic();
	}
	
	/** Unloads the music from OpenAL. */
	public void killMusic() {
		alSourceStop(musicSourceIndex);
		alDeleteSources(musicSourceIndex);
		alDeleteBuffers(musicBufferIndex);
	}
	
	/** Sets the volume of the music source.
	 * @param volume The volume percentage of the source
	 */
	public void setVolume(float volume) {
	    alSourcef(musicSourceIndex, AL_GAIN, 0.01f * volume);
		
	}
	
	/** If new music has been loaded, play it! */
	public void playMusic() {
		alSourcePlay(musicSourceIndex);
	}
	
	/** Pauses the music source. */
	public void pauseMusic() {
		alSourcePause(musicSourceIndex);
	}
	
	/** Returns the name of the current song. */
	public String getName() {
		return songName;
	}
}
