/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersgames.com/
 * 
 * Sound
 * Each instance carries a sound (FLAC format) and its coordinates
 */

package twelveengine.audio;

import static org.lwjgl.openal.AL10.*;

import com.flibitijibibo.flibitFile.FLACFile;

public class Sound {

	/** Sound properties (location in BSP and location in buffer/source array */
	private float[] soundCoordinates;
	private int soundBufferIndex;
	private int soundSourceIndex;
	
	/** Constructor loads the sound file into OpenAL and places it into the BSPGrid based on the passed XML data.
	 * @param fileName The name of the sound file in assets/audio/sound/
	 * @param coords The location of the sound effect in (x,y) format
	 */
	public Sound(String fileName, float xCoord, float yCoord, float volume, boolean looping) {
		// Assign the passed game and BSP coordinates
		soundCoordinates = new float[] {xCoord, yCoord};
		// Load file, create buffer, load file into buffer
		try {
			FLACFile fileIn;
			if (looping)
				fileIn = new FLACFile("audio/ambient/" + fileName + ".flac");
			else
				fileIn = new FLACFile("audio/sound/" + fileName + ".flac");
			soundBufferIndex = alGenBuffers();
	    	alBufferData(soundBufferIndex, fileIn.getFormat(), fileIn.getData(), fileIn.getSampleRate());
	    	fileIn.dispose();
		} catch (Exception e) {
			e.printStackTrace();
		}
	    // Create source
	    soundSourceIndex = alGenSources();
	    alSourcei(soundSourceIndex, AL_BUFFER, soundBufferIndex);
	    // Set source properties
	    setVolume(volume);
	    alSourcef(soundSourceIndex, AL_PITCH, 1.0f);
	    alSourcef(soundSourceIndex, AL_MAX_GAIN, 0.01f);
	    alSource3f(soundSourceIndex, AL_POSITION, soundCoordinates[0], soundCoordinates[1], 0.0f);
		alSource3f(soundSourceIndex, AL_VELOCITY, 0.0f, 0.0f, 0.0f);
		if (looping)
		    alSourcei(soundSourceIndex, AL_LOOPING, AL_TRUE);
		// Play the sound
		playSound();
	}
	
	/** Sets sound location and resulting velocity. */
	public void moveSound(float newX, float newY) {
		alSource3f(soundSourceIndex, AL_POSITION, newX, newY, 0.0f);
		alSource3f(soundSourceIndex, AL_VELOCITY, (newX - soundCoordinates[0]) / 250, (newY - soundCoordinates[1]) / 250, 0.0f);
		soundCoordinates = new float[] {newX, newY};
	}
	
	/** Sets the volume of the music source.
	 * @param volume The volume percentage of the source
	 */
	public void setVolume(float volume) {
		alSourcef(soundSourceIndex, AL_GAIN, 1.0f * volume);
	}
	
	/** Checks to make sure it's still playing. */
	public boolean checkSound() {
		return (alGetSourcei(soundSourceIndex, AL_SOURCE_STATE) == AL_STOPPED);
	}
	
	/** Removes sound from buffer/source, releases buffer/sound array index. */
	public void killSound() {
		stopSound();
		alDeleteSources(soundSourceIndex);
		alDeleteBuffers(soundBufferIndex);
	}
	
	/** Plays the source of the sound effect. */
	public void playSound() {
		alSourcePlay(soundSourceIndex);
	}
	
	/** Stops the source of the sound effect. */
	public void stopSound() {
		alSourceStop(soundSourceIndex);
	}
	
	/** Pauses the source of the sound effect. */
	public void pauseSound() {
		alSourcePause(soundSourceIndex);
	}
}