package twelveengine;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

import org.lwjgl.opengl.GL11;


import twelveengine.actors.Actor;
import twelveengine.actors.Equipment;
import twelveengine.actors.Hitscan;
import twelveengine.actors.Item;
import twelveengine.actors.Pawn;
import twelveengine.actors.Projectile;
import twelveengine.actors.Weapon;
import twelveengine.bsp.BSP;
import twelveengine.data.Player;
import twelveengine.data.Scenario;
import twelveengine.data.Vertex;
import twelveengine.graphics.Origin;
import twelvelib.net.packets.Packet10Instantiate;
import twelvelib.net.packets.Packet11Location;
import twelvelib.net.packets.Packet12Rotation;

public class Game {
	
	//Core Stuff
	public Engine engine;
	
	public Scenario scenario;
	
	public static int steptime = 30;
	public int time = 0;
	
	public Origin origin;
	public BSP bsp;
	
	public ArrayList<Actor> actors = new ArrayList<Actor>();
	
	public Player player;
	
	public Game(Engine e, String s) {
		engine = e;
		loadLevel(s);
		player = new Player(this);	
	}
	
	public void loadLevel(String s) {
		scenario = new Scenario(s);
		bsp = new BSP(this, scenario.bsp);
		origin = new Origin(100);
	}
	
	public void step() {
		//Game step
		player.input();
		int i = 0;
		while(i  <  actors.size()) {
			actors.get(i).step();
			i++;
		}
		player.post();
	}
	
	public void netStep() {
		//Send packets
		if(player.pawn != null) {
			Pawn p = player.pawn;
			engine.network.packetsOut.add(new Packet11Location(p.nid, true, p.location.x, p.location.y, p.location.z, p.velocity.x, p.velocity.y, p.velocity.z));
			engine.network.packetsOut.add(new Packet12Rotation(p.nid, true, p.rotation.x, p.rotation.y, p.rotation.z));
		}
	}
	
	public Actor addObject(String f, int n, Vertex l, Vertex v, Vertex r) {
		ArrayList<String> file = new ArrayList<String>();
	    try {
			String currentLine;
			DataInputStream fileIn = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(f));
		    BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileIn));
	
		    currentLine=fileReader.readLine();
		    while(!currentLine.equals("%EOF")) {
		    	file.add(currentLine);
			    currentLine=fileReader.readLine();
		    }
		    Actor a = createObject(file, n, l, v, r);
		    addActor(a);
		    return a;
	    }
	    catch(Exception e) {
	    	System.err.println("FAILED TO READ OBJECT: " + f);
	    	e.printStackTrace();
	    	return null;
	    }
	}
	
	public void addSimulatedObject(Actor a) {
		Packet10Instantiate i = new Packet10Instantiate(-1, a.file, a.location.x, a.location.y, a.location.z, a.velocity.x, a.velocity.y, a.velocity.z, a.rotation.x, a.rotation.y, a.rotation.z);
		i.simulated = true;
	    engine.network.packetsOut.add(i);
	    addActor(a);
	}
	
	public Actor createObject(ArrayList<String> file, int n, Vertex l, Vertex v, Vertex r) throws Exception {
		String t = findProp(file, "class=");
		Actor a = null;
		if(t.equals("Pawn")) {
			Pawn p = new Pawn(this, n, findProp(file, "model="), findProp(file, "physmodel="));
			p.name = findProp(file, "name=");
			a = p;
		}
		if(t.equals("Item")) {
			Item i = new Item(this, n, findProp(file, "model="));
			i.name = findProp(file, "name=");
			a = i;
		}
		if(t.equals("Weapon")) {
			Weapon w = new Weapon(this, n, findProp(file, "model="), findProp(file, "primaryfire="), findProp(file, "secondaryfire="));
			w.name = findProp(file, "name=");
			w.simulatedProjectile = Boolean.parseBoolean(findProp(file, "simulatedProjectile="));
			w.rof = Integer.parseInt(findProp(file, "rateoffire="));
			w.impulse = Double.parseDouble(findProp(file, "impulse="));
			w.projectiles = Integer.parseInt(findProp(file, "projectiles="));
			w.spread = new Vertex(Double.parseDouble(findProp(file, "spreadx=")),Double.parseDouble(findProp(file, "spready=")),0);
			a = w;
		}
		if(t.equals("Equipment")) {
			Equipment e = new Equipment(this, n, findProp(file, "model="));
			e.name = findProp(file, "name=");
			e.type = findProp(file, "type=");
			e.stacks = Boolean.parseBoolean(findProp(file, "stacks="));
			e.total = Integer.parseInt(findProp(file, "total="));
			e.impulse = Double.parseDouble(findProp(file, "impulse="));
			e.fileCreateOnUse = findProp(file, "createwhenused=");
			a = e;
		}
		if(t.equals("Hitscan")) {
			Hitscan h = new Hitscan(this, n, Integer.parseInt(findProp(file, "lifespan=")));
			h.name = findProp(file, "name=");
			h.damage = Double.parseDouble(findProp(file, "damage="));
			a = h;
		}
		if(t.equals("Projectile")) {
			Projectile p = new Projectile(this, n, findProp(file, "model="));
			p.name = findProp(file, "name=");
			p.life = Integer.parseInt(findProp(file, "lifespan="));
			p.damage = Double.parseDouble(findProp(file, "damage="));
			p.damageRadius = Double.parseDouble(findProp(file, "damageradius="));
			p.force = Double.parseDouble(findProp(file, "force="));
			a = p;
		}
		if(a == null)
			throw new Exception("ERROR PARSING OBJECT!");
		a.file = t;
		a.setLocation(l);
		a.setVelocity(v);
		a.setRotation(r);
		return a;
	}
	
	public String findProp(ArrayList<String> file, String s) {
		int i = 0;
		while(i < file.size()) {
			if(file.get(i).startsWith(s)) {
				return file.get(i).split(s)[1];
			}
			i++;
		}
		return "";
	}
	
	
	public Actor addActor(Actor a) {
		actors.add(a);
		return a;
	}
	
	public Actor getActor(int n) {
		int i = 0;
		while(i < actors.size()) {
			if(actors.get(i).nid == n)
				return actors.get(i);
			i++;
		}
		return null;
	}
	
	public void removeActor(int n) {
		int i = 0;
		while(i < actors.size()) {
			if(actors.get(i).nid == n) {
				if(player.pawn != null)
					if(actors.get(i).nid == player.pawn.nid)
						player.pawn = null;
				actors.remove(i);
			}
			i++;
		}
	}
	
	public void pauseSounds() {
		
	}
	
	public void resumeSounds() {
		
	}
	
	public void adjustSoundVolume() {
		
	}
	
	public void unloadGame() {

	}

	public void checkSoundArray() {
		
	}
	
	public void drawGame() {
		drawMap();
		drawActors();
	}
	
	public void drawMap() {
		createLights();
		bsp.draw();
	}
	
	public void drawActors() {
		origin.draw();
		int i = 0;
		while(i  <  actors.size()) {
			actors.get(i).draw();
			i++;
		}
	}

	public void createLights() {
	    float amb = 1f;
	    float LightAmbient[]  = { amb, amb, amb, 1.0f };
	    float LightDiffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	    float LightPosition[] = { 1.0f,  4.0f, 2.0f, 0.0f };

		ByteBuffer temp = ByteBuffer.allocateDirect(16);
		temp.order(ByteOrder.nativeOrder());
	    GL11.glLight(GL11.GL_LIGHT0, GL11.GL_AMBIENT, (FloatBuffer)temp.asFloatBuffer().put(LightAmbient).flip());
	    GL11.glLight(GL11.GL_LIGHT0, GL11.GL_DIFFUSE, (FloatBuffer)temp.asFloatBuffer().put(LightDiffuse).flip());
	    GL11.glLight(GL11.GL_LIGHT0, GL11.GL_POSITION, (FloatBuffer)temp.asFloatBuffer().put(LightPosition).flip());
	    
	    GL11.glColorMaterial (GL11.GL_FRONT_AND_BACK, GL11.GL_AMBIENT_AND_DIFFUSE);
	    GL11.glEnable(GL11.GL_LIGHT0);
	}
	
	public void log(String s) {
		System.out.println(s);
	}
	
}
