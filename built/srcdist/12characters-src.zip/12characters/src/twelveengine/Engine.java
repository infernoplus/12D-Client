/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersgames.com/
 * 
 * Engine
 * Runs the engine. Stores/calls the graphics, audio, input cores. Also stores frames-per-second.
 */
			
package twelveengine;

import org.lwjgl.Sys;

import twelveengine.audio.AudioCore;
import twelveengine.Game;
import twelveengine.graphics.GraphicsCore;
import twelveengine.network.NetworkCore;
import twelveengine.ui.UICore;

public class Engine {
	
	/** That's the name of the game, baby! */
	public final String gameTitle = "12D Client Alpha";
	public final String version = "v0.0.3 Dev";
	/** Core Instances */
	public Console console;
	public GraphicsCore graphics;
	public AudioCore audio;
	public NetworkCore network;
	public UICore ui;
	public Game game;
	/** Menu variables */
	public boolean menuIsOpen = false;
	/** Kills the program upon enable */
	public boolean stopRuntime = false;
	/** BSP Step Variables */
	private long currentTime;
	private long lastFrame = getTime();
	
	public Thread renderer = null;

	/** Engine starts here! */
	public void start() {
		System.out.println("Loading engine...");
		console = new Console(this);
		graphics = new GraphicsCore(this);
		ui = new UICore(this);
		audio = new AudioCore(this);
		network = new NetworkCore(this);
		System.out.println("\nEngine ready!");
		game = new Game(this, "mainmenu");
	}
	
	public boolean loadGame(String s) {
		try {
			ui.hideAll();
			game.unloadGame();
			game = new Game(this, s);
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}

	/** Engine runs here! */
	public void run() {
		while (!stopRuntime) {
				currentTime = getTime();
				if (currentTime - lastFrame > Game.steptime) {
					//long t = getTime();
			       	game.step();
					network.step();
			       	ui.step();
					//System.out.println("Tick: " + (getTime() - t) + ", Rendered: " + fr);
		        	lastFrame = currentTime;
				}
				renderGame();
		}
    }
	
	public void renderGame() {
		audio.renderAudio();
		graphics.renderGraphics();
	}

	/** Engine ends here! */
	public void end() {
		System.out.println("\nStopping engine...");
		if(game != null)
			game.unloadGame();
		network.close();
		ui.unloadGUI();
		graphics.endGraphics();
		audio.endAudio();
		System.out.println("Game stopped!");
	}
	
	/** Pauses/Unpauses the game and enables/disables the menu. */
	public void toggleMenu() {
		
	}

	/** Get method for the current time.
	 * @return The time in milliseconds, stored as a long.
	 */
    public long getTime() {
        return (Sys.getTime() * 1000) / Sys.getTimerResolution();
    }
}
