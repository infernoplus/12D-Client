/*
 * 12characters Snake Engine
 * © 2011 12characters Games
 * http://www.12charactersengines.com/
 * 
 * UICore
 * Loads and manages in-engine UI and menus, including event handling and display.
 */

package twelveengine.ui;

import java.io.IOException;
import java.util.ArrayList;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

import de.matthiasmann.twl.Button;
import de.matthiasmann.twl.EditField;
import de.matthiasmann.twl.Event;
import de.matthiasmann.twl.GUI;
import de.matthiasmann.twl.Label;
import de.matthiasmann.twl.TextArea;
import de.matthiasmann.twl.Widget;
import de.matthiasmann.twl.renderer.lwjgl.LWJGLRenderer;
import de.matthiasmann.twl.theme.ThemeManager;

import twelveengine.Engine;
import twelvelib.net.packets.Packet50Ready;
import twelvelib.net.packets.Packet53Team;

public class UICore extends Widget {

	// Core UI variables
	private Engine engine;
	private GUI menuGUI;
	private ThemeManager menuTheme;
	
	public boolean showMouse = true;

	//menuItems:
	//0 = main menu
	//1 = join
	//2 = options
	//3 = quit
	//4 = chat
	//5 = local
	//6 = player
	//7 = inventory
	public boolean menuItems[] = new boolean[] {true, false, false, false, false, false, false, false, false};
	
	public ArrayList<Widget> main = new ArrayList<Widget>();
	public ArrayList<Widget> local = new ArrayList<Widget>();
	public ArrayList<Widget> join = new ArrayList<Widget>();
	public ArrayList<Widget> options = new ArrayList<Widget>();
	public ArrayList<Widget> quit = new ArrayList<Widget>();
	
	public ArrayList<Widget> player = new ArrayList<Widget>();
	public ArrayList<Widget> chat = new ArrayList<Widget>();
	public ArrayList<Widget> inventory = new ArrayList<Widget>();
	public ArrayList<Widget> hud = new ArrayList<Widget>();

	
	public UICore(Engine passedGame) {
		engine = passedGame;
		LWJGLRenderer renderer;
		try {
			renderer = new LWJGLRenderer();		
		menuGUI = new GUI(this, renderer);
			menuTheme = ThemeManager.createThemeManager(Thread.currentThread().getContextClassLoader().getResource("ui/ExampleFiles/simple.xml"), renderer);
		}catch (IOException e) {
			e.printStackTrace();
		}
		 catch (LWJGLException e) {
				e.printStackTrace();
		}
		menuGUI.applyTheme(menuTheme);
		
		create();
	}
	
	public EditField connectionMonitor;
	public EditField ipField;
	public EditField portField;
	public EditField nameField;
	
	public EditField levelField;
	public EditField modeField;
	
	public EditField chatField;
	
	public EditField inventoryField;
	public Label healthField;
	public Label weaponField;
	public Label equipmentField;
	
	public EditField teamField;
	
	public void create() {
		EditField e;
		Button b;
		Label l;
		
		//Main menu
		int x = 10;
		int y = 10;
		
		b = (Button) createElement(main, 'b', "topleft", x, y, true);
		b.setText("Local");
		b.adjustSize();
		b.setSize(75, b.getHeight());
		y += b.getHeight();
		
		b.addCallback(new Runnable() {
			public void run() {
				hideAll();
				menuItems[0] = true;
				menuItems[5] = true;
			}
		});
		
		b = (Button) createElement(main, 'b', "topleft", x, y, true);
		b.setText("Join");
		b.adjustSize();
		b.setSize(75, b.getHeight());
		y += b.getHeight();
		
		b.addCallback(new Runnable() {
			public void run() {
				hideAll();
				menuItems[0] = true;
				menuItems[1] = true;
			}
		});
		
		b = (Button) createElement(main, 'b', "topleft", x, y, true);
		b.setText("Options");
		b.adjustSize();
		b.setSize(75, b.getHeight());
		y += b.getHeight();
		
		b.addCallback(new Runnable() {
			public void run() {
				hideAll();
				menuItems[0] = true;
				menuItems[2] = true;
			}
		});
		
		b = (Button) createElement(main, 'b', "topleft", x, y, true);
		b.setText("Quit");
		b.adjustSize();
		b.setSize(75, b.getHeight());
		
		b.addCallback(new Runnable() {
			public void run() {
				hideAll();
				menuItems[0] = true;
				menuItems[3] = true;
			}
		});
		//Local menu
		x += 10 + b.getWidth();
		y = 10;
		
		int xx = x;
		
		e = (EditField) createElement(local, 'i', "topleft", x, y, true);
		e.setMinSize(200, 50);
		e.setMaxSize(200, 50);
		e.adjustSize();
		
		x += e.getWidth();
		
		l = (Label) createElement(local, 'l', "topleft", x, y, true);
		e.setMinSize(200, b.getHeight());
		e.setMaxSize(200, b.getHeight());
		e.setMultiLine(false);
		e.setReadOnly(false);
		e.adjustSize();
		l.setSize(50, e.getHeight());
		l.setText("Level");
		
		levelField = e;
		
		y += e.getHeight() + 10;
		x = xx;
		
		e = (EditField) createElement(local, 'i', "topleft", x, y, true);
		e.setMinSize(200, 50);
		e.setMaxSize(200, 50);
		e.adjustSize();
		
		x += e.getWidth();
		
		l = (Label) createElement(local, 'l', "topleft", x, y, true);
		e.setMinSize(200, b.getHeight());
		e.setMaxSize(200, b.getHeight());
		e.setMultiLine(false);
		e.setReadOnly(false);
		e.adjustSize();
		l.setSize(50, e.getHeight());
		l.setText("Mode");
		
		modeField = e;
				
		y += e.getHeight() + 10;
		x = xx;
		
		b = (Button) createElement(local, 'b', "topleft", x, y, true);
		b.setText("Start");
		b.adjustSize();
		

		
		b.addCallback(new Runnable() {
			public void run() {
				engine.loadGame(levelField.getText());
			}
		});
		
		
		//Join menu
		x = xx;
		y = 10;
		
		e = (EditField) createElement(join, 'i', "topleft", x, y, true);
		e.setMinSize(200, 50);
		e.setMaxSize(200, 50);
		e.adjustSize();
		
		x += e.getWidth();
		
		l = (Label) createElement(join, 'l', "topleft", x, y, true);
		e.setMinSize(200, b.getHeight());
		e.setMaxSize(200, b.getHeight());
		e.setMultiLine(false);
		e.setReadOnly(false);
		e.adjustSize();
		l.setSize(50, e.getHeight());
		l.setText("IP");
		
		ipField = e;
		
		x = xx;
		y += 10 + e.getHeight();
		
		e = (EditField) createElement(join, 'i', "topleft", x, y, true);
		e.setMinSize(200, 50);
		e.setMaxSize(200, 50);
		e.adjustSize();
		
		x += e.getWidth();
		
		l = (Label) createElement(join, 'l', "topleft", x, y, true);
		e.setMinSize(200, b.getHeight());
		e.setMaxSize(200, b.getHeight());
		e.setMultiLine(false);
		e.setReadOnly(false);
		e.adjustSize();
		l.setSize(50, e.getHeight());
		l.setText("Port");
		
		portField = e;
		
		x = xx;
		y += 10 + e.getHeight();
		
		e = (EditField) createElement(join, 'i', "topleft", x, y, true);
		e.setMinSize(200, 50);
		e.setMaxSize(200, 50);
		e.adjustSize();
		
		x += e.getWidth();
		
		l = (Label) createElement(join, 'l', "topleft", x, y, true);
		e.setMinSize(200, b.getHeight());
		e.setMaxSize(200, b.getHeight());
		e.setMultiLine(false);
		e.setReadOnly(false);
		e.adjustSize();
		l.setSize(50, e.getHeight());
		l.setText("Name");
		
		nameField = e;
		
		x = xx;
		y += 10 + e.getHeight();
		
		b = (Button) createElement(join, 'b', "topleft", x, y, true);
		b.setText("Connect");
		b.adjustSize();
		
		b.addCallback(new Runnable() {
			public void run() {
				engine.network.connect(ipField.getText(), Integer.parseInt(portField.getText()), nameField.getText());
			}
		});
		
		x += b.getWidth();
		
		e = (EditField) createElement(join, 'i', "topleft", x, y, true);
		e.setMinSize(200, b.getHeight());
		e.setMaxSize(200, b.getHeight());
		e.setMultiLine(false);
		e.setReadOnly(true);
		e.adjustSize();
		connectionMonitor = e;
		
		//Options
		
		//Quit
		
		x = xx;
		y = 10;
		
		l = (Label) createElement(quit, 'l', "topleft", x, y, true);
		l.setText("Quit?");
		l.adjustSize();
		
		y += l.getHeight();
		
		b = (Button) createElement(quit, 'b', "topleft", x, y, true);
		b.setText("Yes");
		b.adjustSize();
		
		b.addCallback(new Runnable() {
			public void run() {
				hideAll();
				menuItems[0] = true;
				engine.stopRuntime = true;
			}
		});
		
		int width = b.getWidth();
		
		x += b.getWidth();
		
		b = (Button) createElement(quit, 'b', "topleft", x, y, true);
		b.setText("No");
		b.adjustSize();
		
		b.addCallback(new Runnable() {
			public void run() {
				hideAll();
				menuItems[0] = true;
			}
		});
		
		width += b.getWidth();
		
		l.setSize(width, l.getHeight());
		
		ipField.setText("localhost");
		portField.setText("2004");
		nameField.setText("inferno+" + (int)(Math.random()*100));
		levelField.setText("hangemhigh");
		modeField.setText("sp_testing");
		
		//chat
		
		x = 10;
		y = engine.graphics.displayHeight - 110;
		
		e = (EditField) createElement(chat, 'i', "topleft", x, y, true);
		e.setMinSize(300, 100);
		e.setMaxSize(300, 100);
		e.setMultiLine(true);
		e.setReadOnly(true);
		e.adjustSize();
		
		chatField = e;
		
		//inventory
		
		x = engine.graphics.displayHeight - 160;
		y = engine.graphics.displayHeight - 110;
		
		e = (EditField) createElement(inventory, 'i', "topleft", x, y, true);
		e.setMinSize(150, 100);
		e.setMaxSize(150, 100);
		e.setMultiLine(true);
		e.setReadOnly(true);
		e.adjustSize();
		
		y -= 20;
		
		l = (Label) createElement(inventory, 'l', "topleft", x, y, true);
		l.setText(" ");
		l.setMinSize(75, 20);
		l.setMaxSize(75, 20);
		l.adjustSize();
		weaponField = l;
		
		x += 75;
		
		l = (Label) createElement(inventory, 'l', "topleft", x, y, true);
		l.setText(" ");
		l.setMinSize(75, 20);
		l.setMaxSize(75, 20);
		l.adjustSize();
		equipmentField = l;
		
		y -= 20;
		x = engine.graphics.displayHeight - 160;
		
		l = (Label) createElement(inventory, 'l', "topleft", x, y, true);
		l.setText(" ");
		l.setMinSize(150, 20);
		l.setMaxSize(150, 20);
		l.adjustSize();
		healthField = l;
		
		inventoryField = e;
		
		//player
		
		x = 0;
		y = 0;
		
		b = (Button) createElement(player, 'b', "center", x, y, true);
		b.setText("Join Team");
		b.adjustSize();
		
		x += b.getWidth();
		e = (EditField) createElement(player, 'i', "center", x, y, true);
		e.setMinSize(50, b.getHeight());
		e.setMaxSize(50, b.getHeight());
		e.setMultiLine(false);
		e.setReadOnly(false);
		e.adjustSize();
		teamField = e;
		
		b.addCallback(new Runnable() {
			public void run() {
				joinTeam(teamField.getText());
			}
		});

		x = 0;
		y += b.getHeight();
		b = (Button) createElement(player, 'b', "center", x, y, true);
		b.setText("Ready");
		b.adjustSize();
		b.addCallback(new Runnable() {
			public void run() {
				ready();
			}
		});
	}
	
	public void layout() {		
		updateVisible();
	}
	
	public boolean toggleChat = true;
	public boolean toggleInventory = true;
	
	public void updateVisible() {
		int i = 0;
		if(menuItems[0])
			while(i < main.size()) {
				main.get(i).setVisible(true);
				i++;
			}
		else
			while(i < main.size()) {
				main.get(i).setVisible(false);
				i++;
			}
		i = 0;
		if(menuItems[1])
			while(i < join.size()) {
				join.get(i).setVisible(true);
				i++;
			}
		else
			while(i < join.size()) {
				join.get(i).setVisible(false);
				i++;
			}
		i = 0;
		if(menuItems[3])
			while(i < quit.size()) {
				quit.get(i).setVisible(true);
				i++;
			}
		else
			while(i < quit.size()) {
				quit.get(i).setVisible(false);
				i++;
			}
		i = 0;
		if(toggleChat)
			while(i < chat.size()) {
				chat.get(i).setVisible(true);
				i++;
			}
		else
			while(i < chat.size()) {
				chat.get(i).setVisible(false);
				i++;
			}
		i = 0;
		if(menuItems[5])
			while(i < local.size()) {
				local.get(i).setVisible(true);
				i++;
			}
		else
			while(i < local.size()) {
				local.get(i).setVisible(false);
				i++;
			}
		i = 0;
		if(menuItems[6])
			while(i < player.size()) {
				player.get(i).setVisible(true);
				i++;
			}
		else
			while(i < player.size()) {
				player.get(i).setVisible(false);
				i++;
			}
		i = 0;
		if(toggleInventory)
			while(i < inventory.size()) {
				inventory.get(i).setVisible(true);
				i++;
			}
		else
			while(i < inventory.size()) {
				inventory.get(i).setVisible(false);
				i++;
			}
	}
	
	public void hideAll() {
		int i = 0;
		while(i < menuItems.length) {
			menuItems[i] = false;
			i++;
		}
	}
	
	public void step() {
		if(!joinTeam.equals("")) {
			try {
				engine.network.packetsOut.add(new Packet53Team(Integer.parseInt(joinTeam)));
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			joinTeam = "";
		}
		if(ready) {
			try {
				engine.network.packetsOut.add(new Packet50Ready());
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			ready = false;
		}
		if(engine.game.player.pawn != null) {
			inventoryField.setText(engine.game.player.pawn.inventoryContents());
			healthField.setText("Health: " + (int)engine.game.player.pawn.health);
			if(engine.game.player.pawn.weapon != null)
				weaponField.setText(engine.game.player.pawn.weapon.name);
			else
				weaponField.setText("No Weapon");
			if(engine.game.player.pawn.equipment != null)
				equipmentField.setText(engine.game.player.pawn.equipment.name);
			else
				equipmentField.setText("No Equip");
		}
		if(menuItems[0] || menuItems[6]) {
			showMouse = true;
		}
		else {
			showMouse = false;
		}
	}
	
	String joinTeam = "";
	public void joinTeam(String t) {
		joinTeam = t;
	}
	
	boolean ready = false;
	public void ready() {
		ready = true;
		menuItems[6] = false;
	}
	
	String messages[] = new String[] {" ", " ", " ", " ", " ", " "};
	public void addMessage(String s) {
		int i = messages.length-2;
		while(i >= 0) {
			messages[i+1] = messages[i];
			i--;
		}
		messages[0] = s;
		
		i = 0;
		String m = "";
		while(i < messages.length) {
			m = messages[i] + "\n" + m;
			i++;
		}
		chatField.setText(m);
	}
	
	public Widget createElement(ArrayList<Widget> group, char type, String align, int x, int y, boolean b) {
		Widget t = null;
		if(type == 'b') {
			t = new Button();
			t.setTheme("button");
		}
		if(type == 'l') {
			t = new Label();
			t.setTheme("button");
		}
		if(type == 'a') {
			t = new TextArea();
			t.setTheme("button");
		}
		if(type == 'i') {
			t = new EditField();
			t.setTheme("editfield");
		}
		
		int ax = 0, ay = 0;
		int width = engine.graphics.displayWidth;
		int height = engine.graphics.displayHeight;
		
		if(align.equals("topleft")) {
			ax = x; 
			ay = y;
		}
		
		if(align.equals("topright")) {
			ax = x + width; 
			ay = y;
		}
		
		if(align.equals("bottomleft")) {
			ax = x; 
			ay = y + height;
		}
		
		if(align.equals("bottomright")) {
			ax = x + width; 
			ay = y + height;
		}
		
		if(align.equals("center")) {
			ax = x + width/2; 
			ay = y + height/2;
		}
		
		t.setPosition(ax, ay);
		t.adjustSize();
		t.setVisible(false);
		
		if(b) {
			add(t);
			group.add(t);
		}
		
		return t;
	}
	
	public void update() {
		updateVisible();
		menuGUI.update();
	}
	
	public boolean handleEvent(Event evt) {
		if(showMouse) {
			//TODO: This is dumb and needs to go away
			if(evt.isKeyEvent())
				if(evt.isKeyPressedEvent())
					if(evt.getKeyCode() == 1) {
						showMouse = false;
						Mouse.setCursorPosition((int)(Display.getWidth()*0.5), (int)(Display.getWidth()*0.5));
						hideAll();
					}
			//
			
			Mouse.setGrabbed(false);
			return super.handleEvent(evt);
		}
		else {
			Mouse.setGrabbed(true);
			return InputReader.readInput(engine, evt);
		}
	}
	
	public void unloadGUI() {
		menuGUI.destroy();
		menuTheme.destroy();
	}
	
	public void checkSoundArray() {

	}
}