package twelveutil;

import twelveengine.data.Collision;
import twelveengine.data.PhysTriangle;
import twelveengine.data.Vertex;

public class MathUtil {
	
	public static Vertex add(Vertex a, Vertex b) {
		return new Vertex(a.x+b.x, a.y+b.y, a.z+b.z);
	}
	
	public static Vertex subtract(Vertex a, Vertex b) {
		return new Vertex(a.x-b.x, a.y-b.y, a.z-b.z);
	}
	
	public static Vertex multiply(Vertex a, Vertex b) {
		   Vertex c = new Vertex(0f,0f,0f);
		   c.x = a.x * b.x;
		   c.y = a.y * b.y;
		   c.z = a.z * b.z;
		   return c;
	}
	
	public static Vertex multiply(Vertex a, double d) {
		   Vertex c = new Vertex(0f,0f,0f);
		   c.x = a.x * d;
		   c.y = a.y * d;
		   c.z = a.z * d;
		   return c;
	}
	
	public static Vertex normalize(Vertex a) {
		double d = Math.sqrt((a.x*a.x)+(a.y*a.y)+(a.z*a.z));
		if(d == 0)
			return new Vertex(0, 0, 0);
		return new Vertex(a.x/d,a.y/d,a.z/d);
	}
	
	public static Vertex crossProduct(Vertex a, Vertex b) {
		   Vertex c = new Vertex(0f,0f,0f);
		   c.x = a.y * b.z - a.z * b.y;
		   c.y = a.z * b.x - a.x * b.z;
		   c.z = a.x * b.y - a.y * b.x;
		   return c;
		}
	
	public static double dotProduct(Vertex a, Vertex b) {
		double t = 0;
		t += a.x*b.x;
		t += a.y*b.y;
		t += a.z*b.z;
		return t;
	}
	
	public static double magnitude(Vertex a) {
		return Math.sqrt((a.x*a.x) + (a.y*a.y) + (a.z*a.z));
	}
	
	//return distance a to b
	public static double length(Vertex a, Vertex b) {
		double i = a.x-b.x;
		double j = a.y-b.y;
		double k = a.z-b.z;
		return Math.sqrt((i*i)+(j*j)+(k*k));
	}
	
	public static Vertex inverse(Vertex a) {
		return new Vertex(-1*a.x,-1*a.y,-1*a.z);
	}
	
	//starting at location a, move in the direction b distance d and return the new location
	public static Vertex onVector(Vertex a, Vertex b, double d) {
		Vertex c = add(a, multiply(normalize(b), new Vertex(d,d,d)));
		return c;
	}
	
	//rotates vertex n by vertex r
	public static Vertex rotateVertex(Vertex n, Vertex r) {
		double a = (double) ((Math.cos(r.z)*n.x)-(Math.sin(r.z)*n.y));
		double b = (double) ((Math.cos(r.z)*n.y)+(Math.sin(r.z)*n.x));
		double c = n.z;
		
		double i = (double) ((Math.cos(r.y)*a)+(Math.sin(r.y)*c));
		double j = b;
		double k = (double) ((-1f*(Math.sin(r.y)*a))+(Math.cos(r.y)*c));
		
		a = i;
		b = (double) ((Math.cos(r.x)*j)-(Math.sin(r.x)*k));
		c = (double) ((Math.sin(r.x)*j)+(Math.cos(r.x)*k));
		
		return new Vertex(a,b,c);
	}
	
	//returns the steepness of the triangle in comparison to the given normal.
	public static double normalSteep(Vertex n, PhysTriangle t) {
		return length(n, t.normal)/2;
	}
	
	//starting at a and moving the magnitude of b in the direction of b, return the triangle and the reflection angle of collision or null if hitting nothing 
	public static Collision lineTriangleIntersection(Vertex a, Vertex b, PhysTriangle t) {
		//does the line intersect plane of triangle?
		Vertex c = add(a, b);
		Vertex v = normalize(b);
		Vertex i = t.a;
		Vertex j = t.b;
		Vertex k = t.c;
		Vertex normal = t.normal;
		double dp = dotProduct(normal, subtract(k, a)) / dotProduct(normal, v);
		Vertex p = new Vertex(a.x + (dp*v.x),a.y + (dp*v.y),a.z + (dp*v.z));
		//make sure we are not getting a collision in the inverse direction
		if(length(v, normal) >= length(v, inverse(normal))) {
			//does the point land in the triangle?
			Vertex m = subtract(k, i);
			Vertex n = subtract(j, i);
			Vertex o = subtract(p, i);
			
			double dot00 = dotProduct(m, m);
			double dot01 = dotProduct(m, n);
			double dot02 = dotProduct(m, o);
			double dot11 = dotProduct(n, n);
			double dot12 = dotProduct(n, o);
			
			double denom = 1f / ((dot00 * dot11) - (dot01 * dot01));
			double x = ((dot11 * dot02) - (dot01 * dot12)) * denom;
			double y = ((dot00 * dot12) - (dot01 * dot02)) * denom;
			//if the point is in the triangle return a collision
			if(x >= 0 && y >= 0 && x + y < 1) {	
				double ad = length(a, p);
				double bd = length(a, c);
				double cd = length(c, p);
				if(ad <= bd && cd <= bd) {
					Vertex iv = inverse(v);
					dp = dotProduct(normal, iv);
					Vertex r = onVector(new Vertex(0,0,0), subtract(multiply(normal, new Vertex(2*dp,2*dp,2*dp)), iv), length(p, c));
					return new Collision(p, r, t, ad);
				}
			}
		}
		return null;
	}
	
	public static Collision linePlaneIntersection(Vertex a, Vertex b, PhysTriangle t) {
		//does the line intersect plane of triangle?
		Vertex c = add(a, b);
		Vertex v = normalize(b);
		Vertex k = t.c;
		Vertex normal = t.normal;
		double dp = dotProduct(normal, subtract(k, a)) / dotProduct(normal, v);
		Vertex p = new Vertex(a.x + (dp*v.x),a.y + (dp*v.y),a.z + (dp*v.z));
		//make sure we are not getting a collision in the inverse direction
		if(length(v, normal) >= length(v, inverse(normal))) {
			double ad = length(a, p);
			Vertex iv = inverse(v);
			dp = dotProduct(normal, iv);
			Vertex r = onVector(new Vertex(0,0,0), subtract(multiply(normal, new Vertex(2*dp,2*dp,2*dp)), iv), length(p, c));
			return new Collision(p, r, t, ad);
		}
		return null;
	}
	
	//Returns a collision if sphere at location a, with radius r, intersects triangle t
	public static Collision sphereTriangleIntersection(Vertex a, double r, PhysTriangle t) {
		//http://realtimecollisiondetection.net/blog/?p=103
		Vertex A = subtract(t.a, a);
		Vertex B = subtract(t.b, a);
		Vertex C = subtract(t.c, a);
		double rr = r * r;
		Vertex V = crossProduct(subtract(B, A), subtract(C, A));
		double d = dotProduct(A, V);
		double e = dotProduct(V, V);
		boolean sep1 = d * d > rr * e;
		double aa = dotProduct(A, A);
		double ab = dotProduct(A, B);
		double ac = dotProduct(A, C);
		double bb = dotProduct(B, B);
		double bc = dotProduct(B, C);
		double cc = dotProduct(C, C);
		boolean sep2 = (aa > rr) & (ab > aa) & (ac > aa);
		boolean sep3 = (bb > rr) & (ab > bb) & (bc > bb);
		boolean sep4 = (cc > rr) & (ac > cc) & (bc > cc);
		Vertex AB = subtract(B, A);
		Vertex BC = subtract(C, B);
		Vertex CA = subtract(A, C);
		double d1 = ab - aa;
		double d2 = bc - bb;
		double d3 = ac - cc;
		double e1 = dotProduct(AB, AB);
		double e2 = dotProduct(BC, BC);
		double e3 = dotProduct(CA, CA);
		Vertex Q1 = subtract(multiply(A, e1), multiply(AB, d1));
		Vertex Q2 = subtract(multiply(B, e2), multiply(BC, d2));
		Vertex Q3 = subtract(multiply(C, e3), multiply(CA, d3));
		Vertex QC = subtract(multiply(C, e1), Q1);
		Vertex QA = subtract(multiply(A, e2), Q2);
		Vertex QB = subtract(multiply(B, e3), Q3);
		boolean sep5 = (dotProduct(Q1, Q1) > rr * e1 * e1) & (dotProduct(Q1, QC) > 0);
		boolean sep6 = (dotProduct(Q2, Q2) > rr * e2 * e2) & (dotProduct(Q2, QA) > 0);
		boolean sep7 = (dotProduct(Q3, Q3) > rr * e3 * e3) & (dotProduct(Q3, QB) > 0);
		boolean separated = sep1 | sep2 | sep3 | sep4 | sep5 | sep6 | sep7;
		if(!separated) {
			double dist = linePlaneIntersection(a, multiply(inverse(t.normal), r), t).d;
			return new Collision(a, new Vertex(0,0,0), t, dist);
		}
		return null;
		
	}
	
	public static String toString(Vertex a) {
		return "{"+a.x+","+a.y+","+a.z+"}";
	}
}
